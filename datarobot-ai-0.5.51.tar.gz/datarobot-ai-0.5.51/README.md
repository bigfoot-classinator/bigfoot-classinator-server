# DataRobot AI Client

## Installation

The API client is hosted on [PyPI](https://pypi.org/project/datarobot-ai/) and can be installed using `pip` or the newer `pipenv`.

```bash
$ pip install datarobot-ai
```

Python versions 2.7, 3.5, and 3.6 are supported. Other versions may work but are not tested.


For building the documentation, _Python 3_ is required and you'll also need:

    - LaTeX
    - Pandoc (via `apt-get`, `brew`, etc.)


## Getting Started

The first step in working with the client is creating a new instance of it. But first you need your
[API key](http://staging.dragonpanda.drdev.io/keys). Once you have a key, you can provide it to the
client either through an environment variable named `DATAROBOTAI_API_KEY` or directly in the source
code when creating the client.

To create the client, first `import` it and then use it:

```python
from datarobotai.client import DataRobotAIClient
ai = DataRobotAIClient(key='fill-in-key-here')

# you can print client to get info about it
print(ai)
# will print the following:
# DataRobotAIClient version 1.0.0 connecting to 'http://api.dragonpanda.drdev.io' with key 'fill-in-key-here'
```

Once you have created a client, you can start to use it.

## Basic Use

It only takes one call to create a model, and then one more to get your predictions using DataRobot AI.

```python
# model the 'profit' column from the file 'data.csv'
model = ai.fit('/path/to/data.csv', 'profit')

# get predictions from the model with the file 'more-data.csv'
# the `predictions` results will predict the 'profit' values
predictions = ai.predict(model.automodel_id, '/path/to/more-data.csv')
```

This can also be done all in one chained operation. 

```python
predictions = ai.fit('/path/to/data.csv', 'profit').predict('/path/to/more-data.csv').get_result()
```

This is very useful for prototyping, but for code that is meant to get multiple predictions from the same
model, you will want to get the Automodel first, and then call `predict` multiple times.

```python
# you will need a saved automodel_id from a previous call to `fit()`.
model = ai.automodels.get(saved_automodel_id)

some_predictions = model.predict('/path/to/data-file.csv')
other_predictions = model.predict('/path/to/other-file.csv')

```

## Logging

To enable more verbose output from long-running tasks, configure
a logger to display messages. For example:

```python
import logging
logging.basicConfig(level=logging.INFO)
```

### Selectively turn off logging

You can configure your logger to more finely control which messages
you see. For example, to turn off messages from the Task updates,
you could do the following:
```python
import logging
logging.getLogger('datarobotai.task').setLevel(logging.WARNING)
```

## Errors

When an operation in the client fails, a `ClientError` exception is raised. This object has the URL
that was called in the API giving the error, the HTTP status code that was returned, and an error
message giving the details about the error.

## Feedback

If you have client library feedback, the best way to reach us is in the forum:
http://forum.staging.dragonpanda.net/c/client-libraries

## Development

Fork the repository and send a pull request.

## Releasing

This is the present process for releasing the client. This Jarvis job increments the version number, publishes the Python package to Artifactory (for pip install), and publishes the Python package and the HTML docs to the Artifactory as an npm module (for integration with the Portal.)

1. Create a PR (for now, a dummy PR that does nothing of significance: FIXME)
2. Get PR reviewed
3. Ask team to hold off merges to master
4. Ensure branch has latest master (press button to rebase if needed)
5. Ensure all checks are green
6. Execute `jarvis release release_package.sh` in PR
7. Check release Job [here](https://jenkins.hq.datarobot.com/job/Jarvis_Auto_Release/)
8. Merge PR
9. Give team the all clear for merges to master
10. Update the Portal to deploy the new client version. In `package.json` update the version number for 'datarobot-ai-py' to match the new version number created in step 7, and then run `yarn install` to update `yarn.lock'. See [here](https://github.com/datarobot/aie-docs/blob/master/package.json).
    In addition, change the version number for the tar file installation instructions in [the quickstart guide](https://github.com/datarobot/aie-docs/blob/master/src/pages/learn/getting-started/quickstart.md#download-the-client) and [python client library page](https://github.com/datarobot/aie-docs/blob/master/src/pages/learn/clients/python.md#installation) to the version you are releasing. 
