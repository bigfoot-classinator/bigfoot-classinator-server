# -*- coding: utf-8 -*-
from ._version import __version__

API_KEY = 'DATAROBOTAI_API_KEY'
