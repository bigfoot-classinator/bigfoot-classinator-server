import os

from datarobotai import API_KEY
from datarobotai.statuses import Statuses
from datarobotai.projects import ProjectClient

from .http_client import RESTClientObject
from .data import Data
from .learning_sessions import LearningSessions
from .predictions import Predictions
from . import __version__


class DataRobotAIClient(object):
    def __init__(self, session):
        self.session = session

    @classmethod
    def create(cls, key, endpoint='https://developers.datarobot.com/aiapi',
               authorization_type='Bearer'):
        """
        Create an instance of DataRobotAIClient from your credentials to enable your interaction
        with DataRobot AI.

        Parameters
        ----------
        key: str
            The API key created with your DataRobot AI account. This can be created in the API
            Key Management section of your account.
        endpoint: str, optional
            The URL of the DataRobot endpoint. Defaults to https://developers.datarobot.com/aiapi
            if empty.
        authorization_type: str, optional
            The authorization type. Defaults to Bearer.

        Returns
        -------
        DataRobotAIClient : DataRobotAIClient

        Examples
        --------
        .. code-block:: python

            import datarobotai.client as DataRobotAIClient
            dr = DataRobotAIClient.create(key='<datarobot ai token>',
            endpoint='https://developers.datarobot.com/aiapi')
        """
        _key = key or os.environ.get(API_KEY)
        session = RESTClientObject(token=_key,
                                   endpoint=endpoint,
                                   authorization_type=authorization_type)
        return cls(session)

    @property
    def data(self):
        """:ref:`Dataset <dataset_overview>` based API operations

        See :py:class:`Data <datarobotai.data.Data>`.
        """
        return Data(self)

    @property
    def learning(self):
        """:ref:`Learning Session <learning_session_overview>` based API operations

        See :py:class:`LearningSessions <datarobotai.learning_sessions.LearningSessions>`.
        """
        return LearningSessions(self)

    @property
    def predictions(self):
        """:ref:`Prediction <prediction_overview>` based API operations

        See :py:class:`Predictions <datarobotai.predictions.Predictions>`.
        """
        return Predictions(self)

    @property
    def statuses(self):
        """Operations organized by :ref:`tasks <task_overview>` to inspect running jobs

        See :py:class:`Statuses <datarobotai.statuses.Statuses>`.
        """
        return Statuses(self)

    @property
    def projects(self):
        """:ref:`Project <project_overview>` based API operations

        See :py:class:`ProjectClient <datarobotai.projects.ProjectClient>`.
        """
        return ProjectClient(self)

    def create_ai(self, name):
        """
        Create an AI that will learn from past data to predict on new data. Note,
        :ref:`project <project_overview>` is sometimes referred to as AI.

        Parameters
        ----------
        name: str
            The name of the AI

        Returns
        -------
        project : Project

        Examples
        --------
        .. code-block:: python

            import datarobotai.client as DataRobotAIClient
            dr = DataRobotAIClient.create(key='<datarobot ai token>',
            endpoint='https://developers.datarobot.com/aiapi')
            ai = dr.create_ai("My AI")
            ai
            >>>Project(id=u'5c6722e6dbfb7c0027e3bdb9', name=u'My AI')
        """
        return self.projects.create_project(project_name=name)

    def __str__(self):
        return "{} version {} connecting to '{}'".format(
            self.__class__.__name__, __version__, self.session.endpoint)
