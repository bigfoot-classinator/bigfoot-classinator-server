# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import json
from os.path import normpath, basename
import uuid

import backports.csv as csv
import six
from requests_toolbelt import MultipartEncoder

from datarobotai.http_client import InputError
from datarobotai.list_response import Paginator
from .models.dataset import Dataset, DatasetFactory
from .task import Task


class Data(object):
    """:ref:`Dataset <dataset_overview>` based API operations"""

    def __init__(self, ai_client):
        self.ai_client = ai_client
        self.session = ai_client.session

    def _import(self, source, content_type, data):
        response = self.session.post(
            'datasets/{}/'.format(source),
            headers={'Content-Type': content_type, 'Accept': '*/*'},
            data=data)

        return Task(self.session,
                    Task.get_linked_result_url(response.json()),
                    lambda result_url: self.get(basename(normpath(result_url))))

    def import_file(self, file_path):
        """
        Upload a new dataset. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        file_path : str
            The path of the local file to upload

        Returns
        -------
        data : Dataset
            The dataset that was uploaded

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        """
        return self.start_import_file(file_path).get_result()

    def import_data_frame(self, data_frame):
        """
        Upload a new dataset. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        data_frame : pandas.DataFrame
            A Data Frame which will be converted into in-memory buffer and deployed as csv file

        Returns
        -------
        data : Dataset
            The dataset that was uploaded

        Raises
        ------
        TaskTimeout
           If the operation did not finish in the allotted time
        TaskError
           If the task ended without success (aborted or errored)

        """
        return self.start_import_data_frame(data_frame).get_result()

    def start_import_data_frame(self, data_frame):
        """
        Start the process to import a dataset. This method can be used to avoid blocking during
        large data frame imports (:ref:`see here <dataset_size_limits>` for size limitations).
        See the :ref:`task <task_overview>` section for more details.

        Parameters
        ----------
        data_frame : pandas.DataFrame
            A Data Frame which will be converted into in-memory buffer and deployed as csv file

        Returns
        -------
        task : Task
            A task object that provides the current status of an url upload

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        """
        buf = six.StringIO()
        data_frame.to_csv(buf, index=False, encoding='utf-8')
        buf.seek(0)
        encoder = MultipartEncoder(fields={'file': ('{}.csv'.format(uuid.uuid4().hex), buf)})
        return self._import('fileImports', encoder.content_type, encoder)

    def import_list_of_records(self, data_source):
        """
        Upload a new dataset from a list of dicts

        Expected that the dicts passed in the list are flat, in that there are no nested
        dictionaries inside the values, and that each key is the name of a column in the dataset
        and the value is the value for that column.

        An example is what would be produced by calling `pandas.DataFrame.to_dict()`
        with the `records` orientation

        Parameters
        ----------
        data_source: list
            The list of dicts

        Returns
        -------
        data : Dataset
            The Dataset that was uploaded

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)
        InputError
            If the data_source contains invalid input records

        """
        def _bytes_to_unicode(s):
            return s.decode('utf-8') if isinstance(s, bytes) else s
        try:
            buf = six.StringIO()
            headers = [_bytes_to_unicode(k) for k in data_source[0].keys()]
            tmp_csv = csv.DictWriter(buf, fieldnames=headers)
            tmp_csv.writeheader()
            for row in data_source:
                tmp_csv.writerow({_bytes_to_unicode(k): _bytes_to_unicode(v) for k, v in row.items()})
            buf.seek(0)
            return self._import_buffer(buf)
        except ValueError as e:
            raise InputError('Inconsistent input records. {} DataFrame converted into dict '
                             'with `records` orientation is expected'.format(str(e)))

    def _start_import_buffer(self, string_buffer):
        """
        Start the process to import a dataset. This method can be used to avoid blocking during
        large in-memory buffer imports (:ref:`see here <dataset_size_limits>` for size limitations).
        See the :ref:`task <task_overview>` section for more details.

        Parameters
        ----------
        string_buffer : six.StringIO
            Buffer of strings formatted as csv file, will be deployed as a csv file

        Returns
        -------
        task : Task
            A task object that provides the current status of an url upload

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        """
        encoder = MultipartEncoder(fields={'file': ('{}.csv'.format(uuid.uuid4().hex), string_buffer)})
        return self._import('fileImports', encoder.content_type, encoder)

    def _import_buffer(self, string_buffer):
        """
        Upload a new dataset. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        string_buffer : six.StringIO
            Buffer of strings formatted as csv file, will be deployed as a csv file

        Returns
        -------
        data : Dataset
            The dataset that was uploaded

        Raises
        ------
        TaskTimeout
           If the operation did not finish in the allotted time
        TaskError
           If the task ended without success (aborted or errored)

        """
        return self._start_import_buffer(string_buffer).get_result()

    def import_url(self, url):
        """
        Upload a new dataset. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        url : str
            url to a publicly available file

        Returns
        -------
        dataset : Dataset
            The dataset that was uploaded

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        """
        return self.start_import_url(url).get_result()

    def start_import_file(self, file_path):
        """
        Start the process to import a dataset. This method can be used to avoid blocking during
        large file imports (:ref:`see here <dataset_size_limits>` for size limitations).
        See the :ref:`task <task_overview>` section for more details.

        Parameters
        ----------
        file_path : str
            The path of the local file to upload

        Returns
        -------
        task : Task
            A task object that provides the current status of an file upload

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        Examples
        --------
        .. code-block:: python

            task = dr.data.start_import_file(file_path='/home/user/data/large_file.csv')
            while not task.is_complete()
                do_something_else()
            task.get_result()  # will block if process is not complete yet
            >>> 'Dataset(u'5c90e9ff75761b001e7d1959', u'large_file.csv', u'2019-03-19T13:09:19')'

        """

        encoder = MultipartEncoder(fields={'file': (basename(file_path), open(file_path, 'rb'))})
        return self._import('fileImports', encoder.content_type, encoder)

    def start_import_url(self, url):
        """
        Start the process to import a dataset. This method can be used to avoid blocking during
        large file imports (:ref:`see here <dataset_size_limits>` for size limitations).
        See the :ref:`task <task_overview>` section for more details.

        Parameters
        ----------
        url : str
            url to a publicly available file

        Returns
        -------
        task : Task
            A task object that provides the current status of an url upload

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)

        """
        return self._import('urlImports', 'application/json', json.dumps({'url': url}))

    def get(self, dataset_id):
        """
        Retrieve a dataset

        Parameters
        ----------
        dataset_id: str
            The id of the dataset to retrieve

        Returns
        -------
        dataset : Dataset
            The queried dataset

        """
        data = self.session.get('datasets/{}'.format(dataset_id)).json()
        return Dataset.from_server_obj(data, self.ai_client)

    def list(self, offset=0, limit=50, project_id=None):
        """
        Retrieve a list of uploaded datasets associated with this account

        Parameters
        ----------
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to 50.
        project_id : str, optional
            If specified, only datasets associated with this project will be returned

        Returns
        -------
        dataset : list[Dataset]
            A list of :class:`Dataset <datarobotai.models.dataset.Dataset>` objects.

        """
        params = {'offset': offset, 'limit': limit}
        if project_id is not None:
            params['projectId'] = project_id
        dataset_list = self.session.get('datasets/', params=params).json()
        return Paginator.make_paginator(
            factory=DatasetFactory(client=self.ai_client),
            response_data=dataset_list,
            client=self.ai_client
        )

    def delete(self, dataset_id):
        """
        Deletes a dataset

        Parameters
        ----------
        dataset_id: str
            The id of the dataset to delete

        """
        self.session.delete('/datasets/{}/'.format(dataset_id))
