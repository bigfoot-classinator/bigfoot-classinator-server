import os
from datetime import datetime, date
import platform

import requests
from requests.adapters import Retry, HTTPAdapter
from requests_toolbelt import MultipartEncoder
import six
from six.moves.urllib.parse import urlparse

from . import __version__


DEFAULT_CONNECT_TIMEOUT = 6.05
DEFAULT_READ_TIMEOUT = 60
DEFAULT_UPLOAD_TIMEOUT = 600


def _process_response(response):
    if response is None:
        return None, 0, None

    # content type is probably something like 'application/json; charset: utf-8'
    # so this processes that to be useful
    content_type_value = response.headers.get('content-type')
    content_type = None if content_type_value is None else content_type_value.split(';')[0]

    if content_type == 'application/json':
        return response.json(), response.status_code, response.headers
    return response.content, response.status_code, response.headers


def _json_encode(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError("Type %s not serializable" % type(obj))


class BaseHTTPError(Exception):
    """This base class provides the structure for both client and server errors"""

    @classmethod
    def from_response(cls, response):
        return cls(response.request.url,
                   response.status_code,
                   response.text)

    def __init__(self, url, status, body):
        super(BaseHTTPError, self).__init__()
        self._url = url
        self._status = status
        self._error_details = body

    @property
    def url(self):
        return self._url

    @property
    def status(self):
        return self._status

    @property
    def error_details(self):
        return self._error_details

    def __str__(self):
        return 'Error {} returned from {}. Details:\n{}'.format(self._status,
                                                                self._url,
                                                                self._error_details)


class ServerError(BaseHTTPError):
    """
    A server error is generated when the status code in the response from the
    server is 500 or greater
    """


class ClientError(BaseHTTPError):
    """
    A ClientError is generated when the status code in the response from the
    server is 400 or greater.
    """


class LimitExceededError(Exception):
    """
    An LimitExceededError is generated when a user quota is exceeded and status code in the response from the
    server is 429
    """

    def __init__(self, message):
        super(LimitExceededError, self).__init__()
        self._message = message

    def __str__(self):
        return 'Limit exceeded error: {}'.format(self._message)


class InputError(Exception):
    """
    An InputError is generated when an error is found in the input given to the client library.
    This is almost certainly a bug in the client library code. Please file a bug report at:
    https://github.com/datarobot/datarobot-ai-py/issues/new
    """

    def __init__(self, message):
        super(InputError, self).__init__()
        self._message = message

    def __str__(self):
        return 'Input error: {}'.format(self._message)


def handle_error_response(response):
    if 400 <= response.status_code < 500:

        # One-off approach to raising special exception for now. We'll do something more
        # systematic when we have more of these:
        try:
            parsed_json = response.json()  # May raise ValueError if response isn't JSON
        except ValueError:
            parsed_json = {}

        if response.status_code == 429:
            raise LimitExceededError(parsed_json.get('message', ''))

        raise ClientError(response.request.url,
                          response.status_code,
                          body=parsed_json)

    raise ServerError(response.request.url,
                      response.status_code,
                      response.text)


class RESTClientObject(requests.Session):
    def __init__(self, token=None, endpoint=None, connect_timeout=None,
                 verify=True, user_agent_suffix=None, max_retries=None,
                 authorization_type='Bearer'):
        super(RESTClientObject, self).__init__()
        self.endpoint = endpoint
        self.domain = '{}://{}'.format(urlparse(self.endpoint).scheme,
                                       urlparse(self.endpoint).netloc)
        self.authorization_type = authorization_type
        self.token = token
        if connect_timeout is None:
            connect_timeout = DEFAULT_CONNECT_TIMEOUT
        self.connect_timeout = connect_timeout
        self.user_agent_header = self._make_user_agent_header(suffix=user_agent_suffix)
        self.headers.update(self.user_agent_header)
        self.verify = verify
        if max_retries is None:
            # by default, retry connect error but not read error for _all_ requests
            max_retries = Retry(connect=5, read=0, method_whitelist=['GET'], backoff_factor=0.1)
        self.mount('http://', HTTPAdapter(max_retries=max_retries))
        self.mount('https://', HTTPAdapter(max_retries=max_retries))
        self.set_auth(authorization_type, token=token)

    def set_auth(self, authorization_type, token=None):
        if authorization_type == 'Bearer':
            self.headers.update({'Authorization': 'Bearer {}'.format(token)})
        else:
            msg = 'Unsupported authorization type specified in client configuration: {}'
            raise ValueError(msg.format(authorization_type))

    @staticmethod
    def _make_user_agent_header(suffix=None):
        py_version = platform.python_version()
        agent_components = ['DataRobotAI-Python-Client/{}'.format(__version__),
                            '({} {} {})'.format(platform.system(),
                                                platform.release(),
                                                platform.machine()),
                            'Python-{}'.format(py_version)]
        if suffix:
            agent_components.append(suffix)
        return {'User-Agent': ' '.join(agent_components)}

    def _join_endpoint(self, url):
        return '{}/{}'.format(self.endpoint.rstrip('/'), url.lstrip('/'))

    def strip_endpoint(self, url):
        trailing = '' if self.endpoint.endswith('/') else '/'
        expected = '{}{}'.format(self.endpoint, trailing)
        if not url.startswith(expected):
            raise ValueError('unexpected url format: {} does not start with {}'.format(url,
                                                                                       expected))
        return url.split(expected)[1]

    # pylint: disable=arguments-differ
    def request(self, method, url, join_endpoint=False, **kwargs):
        kwargs.setdefault('timeout', (self.connect_timeout, 60))
        if not url.startswith('http') or join_endpoint:
            url = self._join_endpoint(url)
        response = super(RESTClientObject, self).request(method, url, **kwargs)
        if not response:
            handle_error_response(response)
        return response

    def build_request_with_file(self, method, url,
                                fname,
                                form_data=None,
                                content=None,
                                file_path=None,
                                filelike=None,
                                read_timeout=DEFAULT_READ_TIMEOUT,
                                file_field_name='file'):
        """Build request with a file that will use special
        MultipartEncoder instance (lazy load file).


        This method supports uploading a file on local disk, string content,
        or a file-like descriptor. ``fname`` is a required parameter, and
        only one of the other three parameters can be provided.

        Parameters
        ----------
        method : str.
            Method of request. This parameter is required, it can be
            'POST' or 'PUT' either 'PATCH'.
        url : str.
            Url that will be used it this request.
        fname : name of file
            This parameter is required, even when providing a file-like object
            or string content.
        content : str
            The content buffer of the file you would like to upload.
        file_path : str
            The path to a file on a local file system.
        filelike : file-like
            An open file descriptor to a file.
        read_timeout : float
            The number of seconds to wait after the server receives the file that we are
            willing to wait for the beginning of a response. Large file uploads may take
            significant time.
        file_field_name : str
            The name of the form field we will put the data into (Defaults to 'file').

        Returns
        -------
        response : response object.

        """

        bad_args_msg = ('Upload should be used either with content buffer '
                        'or with path to file on local filesystem or with '
                        'open file descriptor')
        assert sum((bool(content),
                    bool(file_path),
                    bool(filelike))) == 1, bad_args_msg

        if file_path:
            if not os.path.exists(file_path):
                raise ValueError(
                    u'Provided file does not exist {}'.format(file_path))
            fields = {file_field_name: (fname, open(file_path, 'rb'))}

        elif filelike:
            filelike.seek(0)
            fields = {file_field_name: (fname, filelike)}
        else:
            if not isinstance(content, six.binary_type):
                raise AssertionError('bytes type required in content')
            fields = {file_field_name: (fname, content)}

        form_data = form_data or {}
        form_data.update(fields)

        encoder = MultipartEncoder(fields=form_data)
        headers = {'Content-Type': encoder.content_type}
        return self.request(method, url, headers=headers, data=encoder,
                            timeout=(self.connect_timeout, read_timeout))
