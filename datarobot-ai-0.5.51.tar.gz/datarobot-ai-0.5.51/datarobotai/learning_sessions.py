from os.path import normpath, basename

from datarobotai.list_response import Paginator
from .models.learning_session import (LearningSession,
                                      LearningSessionFeatures,
                                      LearningSessionFactory)
from .models.deployment import Deployment
from .task import Task


class LearningSessions(object):
    """:ref:`Learning Session <learning_session_overview>` based API operations"""

    def __init__(self, ai_client):
        self.ai_client = ai_client
        self.session = ai_client.session

    def get(self, session_id):
        """ Retrieve a learning session by id

        Parameters
        ----------
        session_id : str
            The id of the learning session to retrieve

        Returns
        -------
        session : :py:class:`LearningSession <datarobotai.models.learning_session.LearningSession>`
        """
        session = self.session.get('learningSessions/{}/'.format(session_id)).json()
        return LearningSession.from_server(session, self.ai_client)

    def list(self, offset=0, limit=50):
        """
        Retrieve a list of learning sessions associated with this account

        Parameters
        ----------
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to 50.

        Returns
        -------
        learning_session : list[LearningSession]
            A list of :class:`LearningSession <datarobotai.models.learning_session.LearningSession>` objects.

        """
        sessions = self.session.get('learningSessions/',
                                    params={'offset': offset, 'limit': limit}).json()
        return Paginator.make_paginator(
            factory=LearningSessionFactory(client=self.ai_client),
            response_data=sessions,
            client=self.ai_client
        )

    def delete(self, session_id):
        """
        Deletes a learning session

        Parameters
        ----------
        session_id: str
            The id of the learning session to delete
        """
        self.session.delete('/learningSessions/{}/'.format(session_id))

    def start_learn(self, target, dataset_id):
        """Set up a learning session without waiting for it to be ready

        To block until the project finishes, use
        :py:meth:`learn <datarobotai.learning_sessions.LearningSessions.learn>` instead, or call
        :py:meth:`get_result <datarobotai.task.Task.get_result>` on the returned Task.

        The resulting learning session can be retrieved with
        :py:meth:`get_result <datarobotai.task.Task.get_result>` once it's ready to predict.

        Parameters
        ----------
        target : str
            The name of the feature from the dataset to learn how to predict
        dataset_id : str
            The id of the :py:class:`dataset <datarobotai.models.dataset.Dataset>` to learn from

        Returns
        -------
        task : :py:class:`Task <datarobotai.task.Task>`
            A task tracking when the new learning session is ready to make predictions.
        """
        response = self.session.post(
            'learningSessions/',
            headers={'Accept': '*/*'},
            json={
                'datasetId': dataset_id,
                'target': target
            })

        return Task(self.session,
                    Task.get_linked_result_url(response.json()),
                    lambda result_url: self.get(basename(normpath(result_url))))

    def wait_for_training_complete(self, session_id):
        """Wait until learning session will be fully completed, blocking method

        Parameters
        ----------
        session_id: str
            The id of the session

        Returns
        -------
        session : :py:class:`LearningSession <datarobotai.models.learning_session.LearningSession>`
        """
        return self.start_complete_training(session_id).get_result()

    def start_complete_training(self, session_id):
        """Create a task for waiting when training will be fully completed

        To block until the learning session will be fully completed, use
        :py:meth:`get_result <datarobotai.task.Task.get_result>` on the returned task.

        Parameters
        ----------
        session_id: str
            The id of the session

        Returns
        -------
        task : :py:class:`Task <datarobotai.task.Task>`
            A task tracking when the learning session is fully completed.
        """
        session = self.session.get('learningSessions/{}/'.format(session_id)).json()
        return Task(self.session,
                    session['links']['status'],
                    lambda result_url: self.get(basename(normpath(result_url))))

    def learn(self, target, dataset_id):
        """
        Create a learning session and wait for it to be able to predict

        Parameters
        ----------
        target: str
            The name of the feature from the dataset to learn how to predict
        dataset_id: str
            The id of the dataset to learn on

        Returns
        -------
        learning_session : LearningSession
            The newly created learning session

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)
        """
        return self.start_learn(target, dataset_id).get_result()

    def get_features(self, session_id):
        """
        Retrieve features associated with a learning session. This set of features must be provided
        to make a :ref:`prediction <prediction_overview>`.

        Parameters
        ----------
        session_id: str
            The id of the session

        Returns
        -------
        learning_session_features : list[LearningSessionFeatures]
            A list of features associated with a learning session.

        """
        session_features = self.session.get(
            'learningSessions/{}/features/'.format(session_id)).json()
        return LearningSessionFeatures(session_features['id'], session_features['target'],
                                       session_features['datasetId'], session_features['features'])

    def get_deployment(self, session_id):
        """Get the deployment associated with this learning session

        The resulting deployment can be used to predict via
        :py:meth:`dr.predictions.deployment_predict <datarobotai.predictions.Predictions.deployment_predict>`,
        although
        :py:meth:`session.predict <datarobotai.models.learning_session.LearningSession.predict>`
        can also be called directly on the LearningSession object.

        Parameters
        ----------
        session_id: str
            The id of the session

        Returns
        -------
        deployment : Deployment

        """
        deployment_info = self.session.get(
            'learningSessions/{}/deployment/'.format(session_id)).json()
        return Deployment.from_server(deployment_info)
