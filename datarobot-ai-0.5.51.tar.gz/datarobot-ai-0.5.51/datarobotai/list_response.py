
class Paginator(object):
    """
    Abstracts the pagination process. Users can iterate over
    this object to exhaust all available results, and pagination
    will happen under the hood.
    """

    def __init__(self, factory, links, total, data, client):
        self._factory = factory
        self._links = links
        self.total = total
        self._data = data
        self._client = client

    @classmethod
    def make_paginator(cls, factory, response_data, client):
        """
        A convenience method for making Paginator objects

        As there is a lot of reusable structure in the responses of list
        endpoints, this is just syntactic sugar to remove the amount
        of keystrokes needed
        """
        return cls(
            factory=factory,
            links=response_data.get('links', {}),  # If no links, API does not have pagination
            # Predictions don't have a total field
            total=response_data.get('total', len(response_data['data'])),
            data=response_data['data'],
            client=client
        )

    def __len__(self):
        return self.total

    def __iter__(self):
        data_page = self._data
        links = self._links
        while True:
            for datum in data_page:
                yield self._factory(datum)
            next_page_link = links.get('next')
            if next_page_link is None:
                return
            next_page_meta = self._client.get(next_page_link).json()
            links = next_page_meta['links']
            data_page = next_page_meta['data']

    def __repr__(self):
        return '{classname}(factory={factoryname}, total={total})'.format(
            classname=self.__class__.__name__,
            factoryname=self._factory.__class__.__name__,
            total=self.total
        )
