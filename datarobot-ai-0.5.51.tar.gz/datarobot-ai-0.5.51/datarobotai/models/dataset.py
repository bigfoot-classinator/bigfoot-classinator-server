
class Dataset(object):
    """
    A reference to a dataset on the DataRobot server.

    Client code that uses the DataRobot AI API package generally should not construct these
    objects directly, they should be instantiated by AI API Client methods.

    This object may be out of sync with the DataRobot server, for example, if multiple
    processes or users have permissions to modify or delete it on the server.

    Attributes
    ----------
    id : str
        Alias for dataset_id
    dataset_id : str
        Unique identifier for this dataset
    name : str
        Human-readable name of this dataset
    created_on : str
        ISO 8601 formatted date and time when the dataset was uploaded,
        like "2019-03-09T22:51:58.394000Z"
    """

    def __init__(self, dataset_id, name, created_on, client):
        self._dataset_id = dataset_id
        self._name = name
        self._created_on = created_on
        self._client = client

    @classmethod
    def from_server_obj(cls, data, client):
        return Dataset(data['id'],
                       data['datasetName'],
                       data['createdOn'],
                       client)

    @property
    def id(self):
        return self.dataset_id

    @property
    def dataset_id(self):
        return self._dataset_id

    @property
    def name(self):
        return self._name

    @property
    def created_on(self):
        return self._created_on

    def __repr__(self):
        return 'Dataset({!r}, {!r}, {!r})'.format(self._dataset_id,
                                                  self._name,
                                                  self._created_on)

    def __eq__(self, other):
        """
        Is this referencing the same object?

        n.b. this may not mean that the data in each object is the same, because they could
        have been fetched at different times. But since they could both be out of date with
        the server, the equality check is simply whether or not they reference the same object
        on the server

        Parameters
        ----------
        other : Dataset

        Returns
        -------
        bool
            Is the other Dataset referencing the same server-side object?
        """
        return self.dataset_id == other.dataset_id


class DatasetFactory(object):
    """
    A factory to produce Dataset objects from server data
    """

    def __init__(self, client):
        self.client = client

    def __call__(self, server_data):
        return Dataset.from_server_obj(server_data, self.client)
