
class Deployment(object):
    """
    A reference to a deployment on the DataRobot server.

    Client code that uses the DataRobot AI API package generally should not construct these
    objects directly, they should be instantiated by AI API Client methods.

    This object may be out of sync with the DataRobot server, for example, if multiple
    processes or users have permissions to modify or delete it on the server.

    Attributes
    ----------
    id : str
        Unique identifier for this deployment
    """

    def __init__(self, deployment_id, url, datarobot_key, *args, **kwargs):
        _ = args  # Future-proofing init
        _ = kwargs  # Future-proofing init
        self.deployment_id = deployment_id
        self.url = url
        self.datarobot_key = datarobot_key

    @property
    def id(self):
        return self.deployment_id

    @classmethod
    def from_server(cls, data):
        return cls(deployment_id=data['deploymentId'],
                   url=data['url'],
                   datarobot_key=data['datarobot-key'])

    def __repr__(self):
        return '{}(url={}, datarobot_key={}, deployment_id={})'.format(
            self.__class__.__name__,
            repr(self.url),
            repr(self.datarobot_key),
            repr(self.deployment_id)
        )

    def __eq__(self, other):
        """
        Is this referencing the same object?

        n.b. this may not mean that the data in each object is the same, because they could
        have been fetched at different times. But since they could both be out of date with
        the server, the equality check is simply whether or not they reference the same object
        on the server

        Parameters
        ----------
        other : Deployment

        Returns
        -------
        bool
            Is the other Deployment referencing the same server-side object?
        """
        return self.deployment_id == other.deployment_id
