class Feature(object):
    """
    A reference to a feature, for example, used in a particular learning session or required for
    an output.

    Client code that uses the DataRobot AI API package generally should not construct these
    objects directly, they should be instantiated by AI API Client methods.

    This object may be out of sync with the DataRobot server, for example, if multiple
    processes or users have permissions to modify or delete it on the server.

    Attributes
    ----------
    name : str
        The name of this feature
    feature_type : str
        The type of this feature, e.g. 'Categorical', 'Text'
    """

    def __init__(self, feature_type, name):
        self._type = feature_type
        self._name = name

    @classmethod
    def from_server(cls, data):
        return cls(data['type'], data['name'])

    @property
    def feature_type(self):
        return self._type

    @property
    def name(self):
        return self._name

    def __repr__(self):
        return 'Feature({!r}, {!r})'.format(self._type, self._name)
