from datarobotai.models.feature import Feature


class LearningSession(object):
    """
    A reference to a learning session on the DataRobot server.

    Client code that uses the DataRobot AI API package generally should not construct these
    objects directly, they should be instantiated by AI API Client methods.

    This object may be out of sync with the DataRobot server, for example, if multiple
    processes or users have permissions to modify or delete it on the server.

    Attributes
    ----------
    id : str
        The id of the learning session
    learning_session_id : str
        The id of the learning session
    dataset_id : str
        The id of the dataset the learning session learned from
    name : str
        The name of the learning session
    target : str
        The target the learning session learned how to predict
    created_on : str
        When the learning session was created
    """
    def __init__(self, _id, dataset_id, name, target, created, client, deployment=None):
        self._id = _id
        self._dataset_id = dataset_id
        self._name = name
        self._target = target
        self._created_on = created
        self._client = client
        self._deployment = deployment

    @classmethod
    def from_server(cls, data, client):
        return cls(data['id'], data['datasetId'], data['name'],
                   data['target'], data['created'], client)

    @property
    def id(self):
        return self._id

    @property
    def learning_session_id(self):
        return self._id

    @property
    def dataset_id(self):
        return self._dataset_id

    @property
    def name(self):
        return self._name

    @property
    def target(self):
        return self._target

    @property
    def created_on(self):
        return self._created_on

    def wait_for_training_complete(self):
        """Wait until learning session will be fully completed, blocking method

        Returns
        -------
        session : :py:class:`LearningSession <datarobotai.models.learning_session.LearningSession>`
        """
        return self._client.learning.wait_for_training_complete(self.id)

    def start_complete_training(self):
        """Create a task for waiting when training will be fully completed

        To block until the learning session will be fully completed, use
        :py:meth:`get_result <datarobotai.task.Task.get_result>` on the returned Task.

        Returns
        -------
        task : :py:class:`Task <datarobotai.task.Task>`
            A task tracking when the learning session is fully completed.
        """
        return self._client.learning.start_complete_training(self.id)

    def predict(self, data):
        """Make predictions on new data using this learning session

        Parameters
        ----------
        data : str, dict, or list
            The data on which to predict. If `str`, assumed to be a filepath on the local
            system. If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list`, then it should be a list of dicts formatted
            as described for `dict`.

        Returns
        -------
        predictions : list[Predictions]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        if self._deployment is None:
            self._deployment = self._client.learning.get_deployment(self.learning_session_id)

        return self._client.predictions.deployment_predict(self._deployment, data)

    def get_features(self):
        """
        Retrieve features associated with this learning session.

        This set of features must be provided to make a :ref:`prediction <prediction_overview>`.

        Returns
        -------
        learning_session_features : list[LearningSessionFeatures]
            A list of features associated with a learning session

        """
        return self._client.learning.get_features(self._id)

    def __repr__(self):
        tmpl = 'LearningSession(id={!r}, dataset_id={!r}, ' \
               'name={!r}, target={!r}, created_on={!r})'
        return tmpl.format(
            self._id, self._dataset_id, self._name, self._target, self._created_on)

    def __eq__(self, other):
        """
        Is this referencing the same object?

        n.b. this may not mean that the data in each object is the same, because they could
        have been fetched at different times. But since they could both be out of date with
        the server, the equality check is simply whether or not they reference the same object
        on the server

        Parameters
        ----------
        other : LearningSession

        Returns
        -------
        bool
            Is the other LearningSession referencing the same server-side object?
        """
        return self.learning_session_id == other.learning_session_id


class LearningSessionFeatures(object):
    """ A list of features associated with a learning session

    Attributes
    ----------
    learning_session_id : str
        The id of the learning session using these features
    target : str
        The target of the learning session using these features
    dataset_id : str
        The id of the dataset these features came from
    feature_list : list[Feature]
        The :py:class:`Features <datarobotai.models.feature.Feature>` used by this learning session
        and required to make predictions
    """
    def __init__(self, learning_session_id, target, dataset_id, feature_list):
        self._learning_session_id = learning_session_id
        self._target = target
        self._dataset_id = dataset_id
        self._feature_list = [Feature(f['type'], f['name'])
                              for f in feature_list]

    @property
    def learning_session_id(self):
        return self._learning_session_id

    @property
    def target(self):
        return self._target

    @property
    def dataset_id(self):
        return self._dataset_id

    @property
    def feature_list(self):
        return self._feature_list

    def __iter__(self):
        return iter(self._feature_list)

    def __repr__(self):
        return 'LearningSessionFeatures({!r}, {!r}, {!r}, {!r})'.format(self._learning_session_id,
                                                                        self._target,
                                                                        self._dataset_id,
                                                                        self._feature_list)


class LearningSessionFactory(object):
    """
    An object to use to create instances of LearningSession from server data
    """
    def __init__(self, client):
        self.client = client

    def __call__(self, server_data):
        return LearningSession.from_server(server_data, self.client)
