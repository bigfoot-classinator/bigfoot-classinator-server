from datarobotai.models.feature import Feature


class Output(object):
    """
    Attributes
    ----------
    name : str
        The name of this output
    target : str
        The target of this output
    source : str
        The source of this output
    """

    def __init__(self, project_id, name, target, source, client, *args, **kwargs):
        _ = args  # Future-proofing init
        _ = kwargs  # Future-proofing init
        self.name = name
        self.target = target
        self.source = source
        self.client = client
        self._project_id = project_id

    @classmethod
    def from_server(cls, project_id, data, client):
        return cls(project_id=project_id,
                   name=data['name'],
                   target=data['target'],
                   source=data.get('source', ''),
                   client=client)

    def __repr__(self):
        return '{}(name={}, target={}, source={})'.format(
            self.__class__.__name__,
            repr(self.name),
            repr(self.target),
            repr(self.source)
        )

    def get_features(self):
        """
        Retrieve a list of features associated with an output

        Returns
        -------
        output_features : list[OutputFeatures]
            A list of features associated with an output

        """
        return self.client.projects.get_output_features(self._project_id, self.name)


class OutputFactory(object):
    """An object that can be used to instantiate Output instances from
    server data
    """

    def __init__(self, project_id, client):
        self.project_id = project_id
        self.client = client

    def __call__(self, data):
        return Output.from_server(self.project_id, data, self.client)


class OutputFeatures(object):
    """
    A list of features associated with an output

    Attributes
    ----------
    feature_list : list[Feature]
        The :py:class:`Features <datarobotai.models.feature.Feature>` used by this output
    """
    def __init__(self, feature_list):
        self._feature_list = feature_list

    @classmethod
    def from_server(cls, data):
        return cls([Feature.from_server(f) for f in data['features']])

    @property
    def feature_list(self):
        return self._feature_list

    def find_feature(self, feature_name):
        """
        Retrieve a particular feature

        Parameters
        ----------
        feature_name : str
            The name of the feature to retrieve

        Returns
        -------
        feature : Feature
            The specified feature, or None is the specified feature is not found
        """
        return next((f for f in self._feature_list if f.name == feature_name), None)

    def __repr__(self):
        return 'OutputFeatures({!r})'.format(self._feature_list)
