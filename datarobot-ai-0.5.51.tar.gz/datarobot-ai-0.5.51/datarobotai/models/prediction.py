
class Prediction(object):
    """
    Attributes
    ----------
    row : int
        The row number of the prediction data
    prediction : str
        The prediction (either a predicted class for classification or the predicted value for
        regression)
    values : dict
        Details on a prediction (i.e. the probability of each label for classification)
    """
    def __init__(self, row, prediction, values):
        self._row = row
        self._prediction = prediction
        self._values = values

    @property
    def row(self):
        return self._row

    @property
    def prediction(self):
        return self._prediction

    @property
    def values(self):
        return self._values

    def score_for(self, class_label):
        """
        Return the model output for the specified class label

        For example, in the binary classification case, what is the probability of the target
        being `foo`, or 1, or whatever values were in the target column of your data.

        This can be used to extract the probability of just a single predicted class for binary
        and multiclass outputs. For regression outputs, this could only ever return values that
        are the same as Prediction.prediction so users are encouraged to use that interface
        (i.e. `prediction_list[0].prediction`)

        Parameters
        ----------
        class_label: str or float or int
            The classification level whose prediction value we want to extract

        Returns
        -------
        score : float
            The model output for the specified label

        Raises
        ------
        ValueError
            If the provided `class_label` is not one of the prediction values of this prediction
        """
        try:
            p_val = next(v for v in self.values if v['label'] == class_label)
            return p_val['value']
        except StopIteration:
            raise ValueError('level `{}` not found in prediction row {}'.format(class_label,
                                                                                repr(self)))

    def __repr__(self):
        return 'Prediction({!r}, {!r}, {!r})'.format(self._row, self._prediction, self._values)


class PredictionFactory(object):
    """An object to generate Prediction objects from server data

    It does not use any state, but the repr for Paginator is written to show the factory name,
    so for the sake of the user we use a class instead of a function
    """

    def __call__(self, server_data):
        return Prediction(server_data['rowId'],
                          server_data['prediction'],
                          server_data['predictionValues'])
