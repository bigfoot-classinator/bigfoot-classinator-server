import os

import six

from datarobotai.http_client import InputError


class Project(object):
    """
    A container for multiple learning sessions, dataset, and other entities in DataRobot AI.

    A project groups together different entities necessary to solve a business problem,
    rather than being strictly focused on delivering a single model without any
    additional context

    Attributes
    ----------
    project_id : str
        The id of the project
    name : str
        The name of the project
    output_count : int
        The number of outputs currently associated with this project
    learning_session_count : int
        The number of learning sessions currently associated with this project
    dataset_count : int
        The number of datasets currently associated with this project

    """

    def __init__(self, project_id, name, output_count, learning_session_count, dataset_count,
                 client):
        """

        Parameters
        ----------
        project_id : str
        name : str
        output_count : int
        learning_session_count : int
        dataset_count : int
        client : DataRobotAIClient
        """
        self.project_id = project_id
        self.name = name
        self.output_count = output_count
        self.learning_session_count = learning_session_count
        self.dataset_count = dataset_count
        self.client = client
        self.dataset_count = dataset_count

    def __repr__(self):
        return 'Project(id={}, name={})'.format(repr(self.project_id), repr(self.name))

    @property
    def id(self):
        return self.project_id

    @classmethod
    def from_server_obj(cls, data, client):
        return cls(data['id'], data['name'], data['outputCount'],
                   data['learningSessionCount'], data['datasetCount'], client)

    def import_file(self, filepath):
        """
        Import a file to a project. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        file_path : str
            The path of the local file to upload

        Returns
        -------
        data : Dataset
            The dataset that was uploaded

        """
        ds = self.client.data.import_file(filepath)
        self.add_dataset(ds)
        return ds

    def import_url(self, url):
        """
        Import a file to a project via a public url. :ref:`See here <dataset_size_limits>` for
        size limitations.

        Parameters
        ----------
        url : str
            The url to a publicly available file

        Returns
        -------
        data : Dataset
            The Dataset that was uploaded

        """
        ds = self.client.data.import_url(url)
        self.add_dataset(ds)
        return ds

    def import_data_frame(self, data_frame):
        """
        Import a data_frame to a project. :ref:`See here <dataset_size_limits>` for size limitations.

        Parameters
        ----------
        data_frame : pandas.DataFrame
            A Data Frame which will be converted into in-memory buffer and deployed as csv file

        Returns
        -------
        data : Dataset
            The Dataset that was uploaded

        """
        ds = self.client.data.import_data_frame(data_frame)
        self.add_dataset(ds)
        return ds

    def learn(self, target, data_source):
        """
        Create a learning session

        Parameters
        ----------
        target: str
            The name of the selected target feature to learn
        data_source: str (file_path), str (dataset_id), list
            The data on which to learn. If `str`, assumed to be a filepath on the local
            system to the existed file - :ref:`see here <dataset_size_limits>` for file size limitations.
            If `str` and not path when it should be formatted as an ObjectId id of dataset.
            If `list` then it should be a `list` of `dicts` formatted with records orientation.

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)
        InputError
            If the data_source contains inconsistent input records

        """
        if isinstance(data_source, six.string_types) and os.path.exists(data_source):
            ds = self.client.data.import_file(data_source)
            dataset_id = ds.dataset_id
        elif isinstance(data_source, six.string_types):
            # Assumed to be a dataset ID
            dataset_id = data_source
        elif isinstance(data_source, list):
            ds = self.client.data.import_list_of_records(data_source)
            dataset_id = ds.dataset_id
        else:
            raise InputError('Unexpected type of the input value. {} has been passed, but '
                             'list, filepath or dataset id are expected.'.format(type(data_source).__name__))
        self._add_dataset_by_id(dataset_id)

        learning_session = self.client.learning.learn(target, dataset_id)
        self.add_learning_session(learning_session, target)

        return self

    def _sync(self):
        server_data = self.client.projects.get(self.project_id)
        self.name = server_data.name
        self.output_count = server_data.output_count
        self.learning_session_count = server_data.learning_session_count
        self.dataset_count = server_data.dataset_count

    def add_learning_session(self, learning_session, output_name=None):
        """
        Add a learning session to a project

        Parameters
        ----------
        learning_session: LearningSession
            The learning session to add
        output_name: str, optional
            The name of the output. Defaults to blank if field is not submitted.

        """
        self.client.projects.add_learning_session(self.project_id,
                                                  learning_session.learning_session_id,
                                                  output_name)
        self._sync()

    def _add_dataset_by_id(self, dataset_id):
        self.client.projects.add_dataset(self.project_id, dataset_id)
        self._sync()

    def _add_output(self, learning_session_id, output_name):
        self.client.projects.add_output(self.project_id, learning_session_id, output_name)
        self._sync()

    def add_dataset(self, dataset):
        """
        Add a dataset to a project

        Parameters
        ----------
        dataset: Dataset
            The dataset which to add

        """
        self._add_dataset_by_id(dataset.dataset_id)

    def add_output(self, learning_session_id, output_name=None):
        """
        Add an output to a project

        Parameters
        ----------
        learning_session_id: str
            The id of the learning session
        output_name: str
            The name of the output. If not specified, the name of the target column from
            the learning session will be used

        """
        self._add_output(learning_session_id, output_name)

    def get_outputs(self):
        """
        Retrieve outputs for a project

        Returns
        -------
        output : list[Output]
            A list of :class:`Output <datarobotai.models.output.Output>` objects.

        """
        return self.client.projects.get_outputs(self.project_id)

    def get_output(self, output_target):
        """
        Retrieve an output for a project

        Parameters
        ----------
        output_target: str
             The target of the output

        Returns
        -------
        output : Output

        """
        return self.client.projects.get_output(self.project_id, output_target)

    def get_learning_sessions(self):
        """
        Retrieve learning sessions for a project

        Returns
        -------
        learning_sessions : list[LearningSession]
            A list of
            :class:`Learning Session <datarobotai.models.learning_session.LearningSession>` objects.

        """
        return self.client.projects.get_learning_sessions(self.project_id)

    def get_datasets(self, offset=0, limit=50):
        """
        Retrieve datasets for a project

        Parameters
        ----------
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to 50.

        Returns
        -------
        dataset : list[Dataset]
            A list of :class:`Dataset <datarobotai.models.dataset.Dataset>` objects.

        """
        return self.client.data.list(offset=offset, limit=limit, project_id=self.project_id)

    def predict(self, target, data):
        """
        Retrieve project predictions

        Parameters
        ----------
        target : str
            The name of the selected target feature to predict
        data : str, dict, list, or iterable
            The data on which to predict. If `str`, assumed to be a filepath on the local
            system - :ref:`see here <dataset_size_limits>` for file size limitations.
            If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list` or `iterable` then it should be a list of dicts formatted
            as described for `dict`.

        Returns
        -------
        predictions : list[Prediction]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        return self.client.predictions.project_predict(self.project_id, target, data)

    def infer(self, target, data):
        """
        Retrieve predictions against new data. This is an alias for
        :meth:`Project.predict <datarobotai.models.project.Project.predict>`

        Parameters
        ----------
        target : str
            The name of the selected target feature to infer
        data : str, dict, list, or iterable
            The data on which to infer. If `str`, assumed to be a filepath on the local
            system - :ref:`see here <dataset_size_limits>` for file size limitations.
            If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list` or `iterable` then it should be a list of dicts formatted
            as described for `dict`.

        Returns
        -------
        predictions : list[Prediction]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        return self.predict(target, data)

    def __eq__(self, other):
        """
        Is this referencing the same object?

        n.b. this may not mean that the data in each object is the same, because they could
        have been fetched at different times. But since they could both be out of date with
        the server, the equality check is simply whether or not they reference the same object
        on the server

        Parameters
        ----------
        other : Project

        Returns
        -------
        bool
            Is the other project referencing the same server-side object?
        """
        return self.project_id == other.project_id


class _Reference(object):

    def __init__(self, reference_id, name):
        self.reference_id = reference_id
        self.name = name

    @classmethod
    def from_server_obj(cls, data):
        return cls(data['referenceId'], data['name'])

    @property
    def id(self):
        return self.reference_id

    def __repr__(self):
        classname = self.__class__.__name__
        return '{}(id={}, name={})'.format(classname, repr(self.reference_id), repr(self.name))


class DatasetReference(_Reference):
    """
    A reference to a dataset on the server
    """


class LearningSessionReference(_Reference):

    @classmethod
    def from_server_obj(cls, data):
        return LearningSessionReference(data['referenceId'], data['name'])

    def __repr__(self):
        classname = self.__class__.__name__
        return '{}(id={}, name={})'.format(classname, repr(self.reference_id), repr(self.name))


class ProjectFactory(object):
    """
    An object to use to instantiate Project instances from server data
    """
    def __init__(self, client):
        self.client = client

    def __call__(self, server_data):
        return Project.from_server_obj(server_data, self.client)
