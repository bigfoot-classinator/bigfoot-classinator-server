
class Status(object):
    """
    Attributes
    ----------
    id : str
        The status id
    status_id : str
        The status id
    status : str
        The status of this request
    code : str
        The status code
    description : str
        A description of the status error
    created : str
        The date this task was created
    message : str
        The status message
    status_type : str
        The type of status
    """

    def __init__(self, status_id, status, code, description, created, message, status_type):
        self._status_id = status_id
        self._status = status
        self._code = code
        self._description = description
        self._created = created
        self._message = message
        self._status_type = status_type

    @property
    def id(self):
        return self._status_id

    @property
    def status_id(self):
        return self._status_id

    @property
    def status(self):
        return self._status

    @property
    def code(self):
        return self._code

    @property
    def description(self):
        return self._description

    @property
    def created(self):
        return self._created

    @property
    def message(self):
        return self._message

    @property
    def status_type(self):
        return self._status_type

    def __repr__(self):
        return 'Status({!r}, {!r}, {!r}, {!r}, {!r}, {!r}, {!r})'.format(self._status_id,
                                                                         self._status,
                                                                         self._code,
                                                                         self._description,
                                                                         self._created,
                                                                         self._message,
                                                                         self._status_type)


class StatusFactory(object):
    """
    Generates a Status object from server data.

    It does not use any state, but the repr for Paginator is written to show the factory name,
    so for the sake of the user we use a class instead of a function
    """

    def __call__(self, server_data):
        return Status(server_data['statusId'],
                      server_data['status'],
                      server_data['code'],
                      server_data['description'],
                      server_data['created'],
                      server_data['message'],
                      server_data['statusType'],
                      )
