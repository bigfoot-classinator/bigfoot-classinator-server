import json
from os.path import basename
import sys

try:
    import pandas as pd
except ImportError:
    pd = None
import requests
from requests_toolbelt import MultipartEncoder
import six

from .http_client import InputError, handle_error_response, ClientError
from .list_response import Paginator
from .models.prediction import PredictionFactory
from .models.deployment import Deployment
from .utils import NumpyEncoder

PY3 = sys.version_info[0] > 2


class Predictions(object):
    def __init__(self, ai_client):
        self.ai_client = ai_client
        self.session = ai_client.session

    def _make_file_prediction_request(self, endpoint, filename, data, datarobot_key=None):
        """
        Make a file-based prediction request to the specified synchronous prediction endpoint

        Parameters
        ----------
        endpoint : basestring
            Where the prediction request should be sent
        filename : basestring
            The filename that should accompany the data
        data : BinaryIO
            The actual data
        datarobot_key : basestring, optional
            If provided, the server key

        Returns
        -------
        requests.Response
            The response of the prediction request

        """
        encoder = MultipartEncoder(fields={'file': (filename, data)})

        headers = self.session.headers.copy()
        headers.update({'Content-Type': encoder.content_type})

        if datarobot_key:
            headers['datarobot-key'] = datarobot_key

        response = requests.post(
            endpoint,
            headers=headers,
            data=encoder
        )
        return response

    def _make_in_memory_buffer_prediction_request(self, endpoint, csv_buffer, datarobot_key=None):
        """
        Make a file-based prediction request with converted in-memory buffer
        to the specified synchronous prediction endpoint

        Parameters
        ----------
        endpoint : basestring
            Where the prediction request should be sent
        csv_buffer : io.BytesIO, io.StringIO
            The actual csv-formatted data in the buffer
        datarobot_key : basestring, optional
            If provided, the server key

        Returns
        -------
        requests.Response
            The response of the prediction request

        """
        headers = self.session.headers.copy()
        headers.update({'Content-Type': 'text/csv'})

        if datarobot_key:
            headers['datarobot-key'] = datarobot_key

        response = requests.post(
            endpoint,
            headers=headers,
            data=csv_buffer
        )
        return response

    def _predict(self, endpoint, data_file, datarobot_key):
        with open(data_file, 'rb') as fh:
            response = self._make_file_prediction_request(endpoint,
                                                          basename(data_file),
                                                          fh,
                                                          datarobot_key)

        if not response:
            handle_error_response(response)

        return Paginator.make_paginator(
            factory=PredictionFactory(),
            response_data=response.json(),
            client=None  # predictions are not paginated, don't need a client
        )

    def _predict_json(self, endpoint, datarobot_key, payload):
        """
        Send a json-based prediction to the specified prediction server

        Parameters
        ----------
        endpoint : basestring
            Where the prediction request should be sent
        datarobot_key : basestring, optional
            If provided, the server key
        payload : list
            the data on which to predict. The prediction server requires data to be in the
            list-of-objects format

        Returns
        -------
        requests.Response
            The response from the server

        """
        try:
            serialized_payload = json.dumps(payload, cls=NumpyEncoder)
        except (TypeError, ValueError):
            raise ValueError("Invalid input object. {}".format(sys.exc_info()[1]))

        headers = self.session.headers.copy()
        headers['Content-Type'] = 'application/json'

        if datarobot_key:
            headers['datarobot-key'] = datarobot_key

        response = requests.post(
            endpoint,
            headers=headers,
            data=serialized_payload
        )

        if not response:
            handle_error_response(response)

        return Paginator.make_paginator(
            factory=PredictionFactory(),
            response_data=response.json(),
            client=None  # predictions are not paginated, don't need a client
        )

    def _predict_df(self, endpoint, data_frame, datarobot_key):
        """
        Convert `pandas.DataFrame` into in-memory buffer and send prediction request.

        Parameters
        ----------
        endpoint : basestring
            Where the prediction request should be sent
        data_frame: pandas.DataFrame
            The data on which to predict. A Data Frame which will be converted into in-memory buffer and
            send in prediction request.
        datarobot_key : basestring, optional
            If provided, the server key

        Returns
        -------
        requests.Response
            The response from the server

        """
        buf = data_frame.to_csv(index=False, encoding='utf-8')
        response = self._make_in_memory_buffer_prediction_request(endpoint,
                                                                  csv_buffer=buf.encode('utf-8') if PY3 else buf,
                                                                  datarobot_key=datarobot_key)
        if not response:
            handle_error_response(response)

        return Paginator.make_paginator(
            factory=PredictionFactory(),
            response_data=response.json(),
            client=None  # predictions are not paginated, don't need a client
        )

    def deployment_predict(self, deployment, data):
        """
        Send a prediction request to the specified deployment

        Parameters
        ----------
        deployment : Deployment
            Who will service the request
        data : str, dict, pandas.DataFrame or list
            The data on which to predict. If `str`, assumed to be a filepath on the local
            system. If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list`, then it should be a list of dicts formatted
            as described for `dict`. If `pandas.DataFrame` then it would be converted into in-memory buffer
            and deployed as a file

        Returns
        -------
        prediction_list : list[PredictionList]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        if isinstance(data, six.string_types):
            return self._predict(deployment.url, data, deployment.datarobot_key)
        if isinstance(data, dict):
            # n.b. formatted to list-of-dict to fit prediction server API
            return self._predict_json(deployment.url, deployment.datarobot_key,
                                      payload=[data])
        if pd and isinstance(data, pd.DataFrame):
            return self._predict_df(deployment.url, data, deployment.datarobot_key)
        # only other accepted type is list-of-dicts
        return self._predict_json(deployment.url, deployment.datarobot_key,
                                  payload=data)

    def project_predict(self, project_id, target, data):
        """
        Retrieve project predictions against data. Note, a model must be trained with
        :meth:`LearningSession.learn <datarobotai.learning_sessions.LearningSessions.learn>`
        before predictions can occur.

        Parameters
        ----------
        project_id : str
            The id of the project which to predict on
        target : str
            The name of the selected target feature to predict
        data : str, dict, pandas.DataFrame, list, or iterable
            The data on which to predict. If `str`, assumed to be a filepath on the local
            system. If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list` or `iterable` then it should be a list of dicts formatted
            as described for `dict`. If `pandas.DataFrame` then it would be converted into in-memory buffer
            and deployed as a file

        Returns
        -------
        prediction : list[Prediction]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        try:
            output = self.ai_client.projects.get_output(project_id, target)
            source = output.source

            deployment = Deployment(source['deploymentId'], source['url'], source['datarobot-key'])

            return self.deployment_predict(deployment, data)

        except ClientError:
            raise InputError('No outputs were found for target {} on project {}.'
                             'Have you trained a model by calling '
                             '`learn`?'.format(target, project_id))
