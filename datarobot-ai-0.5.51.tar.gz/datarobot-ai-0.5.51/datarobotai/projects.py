from six.moves import urllib

from datarobotai.http_client import ClientError
from datarobotai.list_response import Paginator
from datarobotai.models.learning_session import LearningSessionFactory
from datarobotai.models.output import Output, OutputFeatures, OutputFactory
from datarobotai.models.project import Project, ProjectFactory
from .task import Task


class ProjectClient(object):
    """:ref:`Project <project_overview>` based API operations"""

    def __init__(self, ai_client):
        self.ai_client = ai_client
        self.session = ai_client.session

    def _raw_fetch(self, project_location):
        response = self.session.get(project_location)
        if response.status_code != 200:
            raise ClientError.from_response(response)

        return Project.from_server_obj(response.json(), self.ai_client)

    def get(self, project_id):
        """
        Retrieve a project

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve

        Returns
        -------
        project : Project
            The queried project

        Examples
        --------
        .. code-block:: python

            import datarobotai.client as DataRobotAIClient
            dr = DataRobotAIClient.create(key='<datarobot ai token>')
            project = dr.projects.get(project_id='54e639a18bd88f08078ca831')
            project.id
            >>>'54e639a18bd88f08078ca831'
            project.name
            >>>'Name of Project'

        """
        location = 'projects/{}/'.format(project_id)
        return self._raw_fetch(location)

    def list(self, offset=None, limit=None):
        """
        Retrieve a list of all projects associated with this account

        Parameters
        ----------
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to no limit.

        Returns
        -------
        project : list[Project]
            A list of :class:`Project <datarobotai.models.project.Project>` objects.

        """
        params = {}
        if offset is not None:
            params['offset'] = offset
        if limit is not None:
            params['limit'] = limit

        projects_list = self.session.get('projects/', params=params).json()
        return Paginator.make_paginator(
            factory=ProjectFactory(self.ai_client),
            response_data=projects_list,
            client=self.ai_client
        )

    def create_project(self, project_name):
        """
        Create a project with a given name

        Parameters
        ----------
        project_name: str
            The name of the project

        Returns
        -------
        project : Project

        """
        response = self.session.post(
            'projects/',
            json={'name': project_name})

        if response.status_code != 201:
            raise ClientError.from_response(response)

        return self._raw_fetch(Task.get_linked_result_url(response.json()))

    def delete(self, project_id):
        """
        Deletes a project

        Parameters
        ----------
        project_id: str
            The id of the project to delete

        """
        self.session.delete(
            'projects/%s/' % project_id
        )

    def add_learning_session(self, project_id, learning_session_id, output_name=None):
        """
        Adds a :ref:`learning session <learning_session_overview>` to the project

        Parameters
        ----------
        project_id : str
            The id of the project to which you want to add the learning session
        learning_session_id : str
            The id of the learning session to add
        output_name: str, optional
            Name of the output this project will learn

        """

        body = {'learningSessionId': learning_session_id}
        if output_name:
            body['outputName'] = output_name

        response = self.session.post(
            'projects/{}/learningSessions/'.format(project_id),
            json=body
        )
        if response.status_code != 201:
            raise ClientError.from_response(response)

    def add_dataset(self, project_id, dataset_id):
        """
        Adds a :ref:`dataset <dataset_overview>` to the project

        Parameters
        ----------
        project_id : str
            The id of the project to which you want to add the dataset
        dataset_id : str
            The id of the dataset to add

        """
        response = self.session.post(
            'projects/{}/datasets/'.format(project_id),
            json={'datasetId': dataset_id}
        )

        if response.status_code != 201:
            raise ClientError.from_response(response)

    def get_outputs(self, project_id, offset=None, limit=None):
        """
        Retrieve a list of all outputs associated with a project

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve outputs for
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to no limit.

        Returns
        -------
        output : list[Output]
            A list of :class:`Output <datarobotai.models.output.Output>` objects.

        """
        url = 'projects/{}/outputs/'.format(project_id)
        params = {}
        if offset is not None:
            params['offset'] = offset
        if offset is not None:
            params['limit'] = limit
        list_data = self.session.get(url, params=params).json()
        return Paginator.make_paginator(factory=OutputFactory(project_id, self.ai_client),
                                        response_data=list_data,
                                        client=self.ai_client)

    def get_output(self, project_id, output_target):
        """
        Retrieve the :ref:`outputs <output_overview>` associated with a project and target

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve an output for
        output_target: str
            The target of this output

        Returns
        -------
        output : Output

        """
        url = 'projects/{}/outputs/{}'.format(project_id, urllib.parse.quote(output_target))
        data = self.session.get(url).json()
        return Output.from_server(project_id, data, self.ai_client)

    def add_output(self, project_id, learning_session_id, output_name=None):
        """
        Adds a :ref:`outputs <output_overview>` to the project

        Parameters
        ----------
        project_id : str
            The id of the project to which you want to add the dataset
        learning_session_id : str
            The id of the learning session
        output_name: str
            The name of the output. If not specified, the name of the target column from
            the learning session will be used

        """
        data = {'learningSessionId': learning_session_id}
        if output_name:
            data['outputName'] = output_name

        response = self.session.put(
            'projects/{}/outputs/'.format(project_id),
            json=data
        )

        if response.status_code != 201:
            raise ClientError.from_response(response)

    def get_output_features(self, project_id, output_target):
        """
        Retrieve features of an output associated with a project and target

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve output features for
        output_target: str
            The target of this output

        Returns
        -------
        output_features : list[OutputFeatures]
            A list of features associated with an output.

        """
        url = 'projects/{}/outputs/{}/features/'.format(project_id, urllib.parse.quote(output_target))
        data = self.session.get(url).json()
        return OutputFeatures.from_server(data)

    def get_learning_sessions(self, project_id, offset=None, limit=None):
        """
        Retrieve a list of all learning sessions associated with a project

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve learning sessions for
        offset: int, optional
            This many results will be skipped. Defaults to 0.
        limit: int, optional
            At most this many results are returned. Defaults to no limit.

        Returns
        -------
        learning_sessions : list[LearningSession]
            A list of :class:`LearningSession <datarobotai.models.learning_session.LearningSession>` objects.

        """
        params = {'projectId': project_id}
        if offset is not None:
            params['offset'] = offset
        if offset is not None:
            params['limit'] = limit
        sessions = self.session.get('learningSessions/', params=params).json()
        return Paginator.make_paginator(
            factory=LearningSessionFactory(client=self.ai_client),
            response_data=sessions,
            client=self.ai_client
        )

    def predict(self, project_id, target, data):
        """
        Retrieve predictions associated with a project, target and dataset

        Parameters
        ----------
        project_id: str
            The id of the project to retrieve predictions for
        target: str
            The name of the selected target feature to predict on
        data : str, dict, or list
            The data on which to predict. If `str`, assumed to be a filepath on the local
            system - :ref:`see here <dataset_size_limits>` for file size limitations.
            If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list`, then it should be a list of dicts formatted
            as described for `dict`.

        Returns
        -------
        predictions : list[Prediction]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        return self.infer(project_id, target, data)

    def infer(self, project_id, target, data):
        """
        Retrieve predictions against new data. Note, a project must be trained with
        :meth:`LearningSession.learn <datarobotai.learning_sessions.LearningSessions.learn>`
        before infer can occur.

        Parameters
        ----------
        project_id : str
            The id of the project to infer data
        target : str
            The name of the selected target feature to infer
        data : str, dict, list, or iterable
            The data on which to infer. If `str`, assumed to be a filepath on the local
            system - :ref:`see here <dataset_size_limits>` for file size limitations.
            If `dict`, should contain the information for a single
            row of data, i.e. the keys should be the feature names, and the values should be the
            feature values. If `list` or `iterable` then it should be a list of dicts formatted
            as described for `dict`.

        Returns
        -------
        predictions : list[Prediction]
            A list of :class:`Prediction <datarobotai.models.prediction.Prediction>` objects.

        """
        return self.ai_client.predictions.project_predict(project_id, target, data)
