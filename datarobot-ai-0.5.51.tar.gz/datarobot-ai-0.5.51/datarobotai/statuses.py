from datarobotai.list_response import Paginator
from .models.status import StatusFactory


class Statuses(object):
    def __init__(self, ai_client):
        self.ai_client = ai_client
        self.session = ai_client.session

    def list(self):
        """
        A list with status information on all :ref:`tasks <task_overview>` currently running for
        this account

        Returns
        -------
        status_list : Paginator
            A list of :class:`Status <datarobotai.models.status.Status>` objects

        """
        status_list = self.session.get('status/').json()
        return Paginator.make_paginator(factory=StatusFactory(),
                                        response_data=status_list,
                                        client=self.ai_client)
