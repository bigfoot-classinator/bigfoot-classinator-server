from time import sleep
import random
import logging


logger = logging.getLogger(__name__)


class TaskError(Exception):
    """
    Raised during execution of Task.get_result if the task errored or was aborted
    """


class TaskTimeout(Exception):
    """
    Raised if a task times out before it completes.
    """


class Task(object):
    """
    This object is used to wait for asynchronous tasks to complete.

    Construction of the object requires an instance of RESTClientObject used to make authenticated
    API calls, the URL that was given back as the status checking URL, and a function to run when
    the task is complete. The function will receive the URL returned from the status endpoint as
    the location of the new object. The function should return a value that will be used as the
    result of the Task.

    Calling `get_result()` on this object will block until the operation completes, times out, or
    fails. It will return the result of the asynchronous operation once it is complete. If it
    times out or fails the return value is `None` and the `is_complete`, `timed_out` and
    `is_successful` properties should be used to determine the state of the result.

    It has two boolean properties (`is_complete` and `successful`) that can be used to implement
    your own polling algorithm. Once `is_complete` is `True`, `get_result()` will return the
    result if `successful` or `None` if not `successful`.
    """

    default_timeout = 30 * 60  # 30 minutes
    max_wait = 5  # 5 seconds

    def __init__(self, session, task_url, get_callback):
        self.session = session
        self.task_url = task_url
        self.get_callback = get_callback
        self.did_time_out = False
        self.status = None
        self.message = None
        self.links = None

    def get_result(self, timeout=None):
        """
        Wait until the operation completes, and return its output

        Parameters
        ----------
        timeout : int, optional
            The number of seconds to wait before giving up on the operation

        Returns
        -------
        object
            Depends on the underlying task

        Raises
        ------
        TaskTimeout
            If the operation did not finish in the allotted time
        TaskError
            If the task ended without success (aborted or errored)
        """
        if self.is_successful():
            return self.get_callback(self.links['result'])

        current_timeout = timeout or self.default_timeout
        elapsed = 0
        i = 0
        while True:
            # if we timed out, say so and exit the loop
            if elapsed >= current_timeout:
                self.did_time_out = True
                raise TaskTimeout('Task did not complete in time ({}s)'.format(current_timeout))

            # AWS says adding jitter to your exponential backoff is good:
            # https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/
            # current configuration makes it exponential until about 10 iterations,
            # and then uses `max_wait`
            wait = random.uniform(0, min(self.max_wait, 2**i))
            logger.debug('Waiting %f seconds', wait)
            sleep(wait)

            # after sleeping, check status and quit if done
            if self.is_successful():
                return self.get_callback(self.links['result'])

            if self.is_failure_status(self.status):
                raise TaskError('Task did not complete successfully: {}'.format(self.message))

            # update loop variables
            i = i + 1
            elapsed = elapsed + wait

    @staticmethod
    def is_complete_status(status_value):
        return status_value.lower() in ('aborted', 'completed', 'error')

    @staticmethod
    def is_failure_status(status_value):
        return status_value.lower() in ('aborted', 'error')

    def is_complete(self):
        """
        Check if a task is complete

        Returns
        -------
        is_complete : bool
            True when the operation has completed. A task is also complete when it has aborted or
            errored and is no longer running.

        """
        self.sync_status()
        return self.is_complete_status(self.status)

    def is_successful(self):
        """
        Check if a task is successful

        Returns
        -------
        is_successful : bool
            True when the operation was successful, False when the API indicated there was an error
            with the operation, or if the operation is not yet complete

        """
        return self.is_complete() and self.status.lower() == 'completed'

    @property
    def timed_out(self):
        """
        Check if a task timed out

        Returns
        -------
        timed_out : bool
            True if the operation took longer than the timeout given to get_result() or if the
            default_timeout was exceeded.

        """
        return self.did_time_out

    def sync_status(self):
        response = self.session.get(self.task_url, allow_redirects=False)
        data = response.json()
        self.status = data['status']
        self.message = data['message']
        self.links = data['links']

        log_msg = '{status}: {detail}'.format(
            status=self.status,
            detail=self.message
        )
        logger.info(log_msg)

        return data

    @staticmethod
    def get_linked_result_url(response_json):
        result_link = response_json['links']['result']
        return result_link
