"""API client utils module. It covers internal utilities and tools methods not included in other modules."""

import json

try:
    import numpy as np
except ImportError:
    np = None


class NumpyEncoder(json.JSONEncoder):
    """Json encoder for numpy data types."""
    def default(self, obj):
        if np and isinstance(obj, np.integer):
            return int(obj)
        elif np and isinstance(obj, np.floating):
            return float(obj)
        elif np and isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(NumpyEncoder, self).default(obj)
