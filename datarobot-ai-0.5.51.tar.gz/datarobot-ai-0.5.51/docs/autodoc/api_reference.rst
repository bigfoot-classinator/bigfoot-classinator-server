API Reference
#############

Client
======

.. autoclass:: datarobotai.client.DataRobotAIClient
   :members:

.. autoclass:: datarobotai.data.Data
   :members:

.. autoclass:: datarobotai.projects.ProjectClient
   :members:

.. autoclass:: datarobotai.learning_sessions.LearningSessions
   :members:

.. autoclass:: datarobotai.predictions.Predictions
   :members:

.. autoclass:: datarobotai.statuses.Statuses
   :members:

Dataset
=======

.. autoclass:: datarobotai.models.dataset.Dataset
   :members:

Deployment
==========

.. autoclass:: datarobotai.models.deployment.Deployment
   :members:

Feature
=======

.. autoclass:: datarobotai.models.feature.Feature
   :members:

Learning Session
================

.. autoclass:: datarobotai.models.learning_session.LearningSession
   :members:
.. autoclass:: datarobotai.models.learning_session.LearningSessionFeatures
   :members:

Output
======

.. autoclass:: datarobotai.models.output.Output
   :members:

.. autoclass:: datarobotai.models.output.OutputFeatures
   :members:

Prediction
==========

.. autoclass:: datarobotai.models.prediction.Prediction
   :members:

Project (AI)
============

.. autoclass:: datarobotai.models.project.Project
   :members:

Status
======

.. autoclass:: datarobotai.models.status.Status
   :members:

Task
====

.. autoclass:: datarobotai.task.Task
   :members:


