.. _dataset_overview:

#######
Dataset
#######

A *dataset* represents data that has been uploaded to the system,
either a historical dataset with known values that can be used for learning or a new dataset to generate predictions for.

.. _dataset_size_limits:

Size Limitations
****************
Currently we support:

- Maximum Training Data file size of 10mb
- Maximum Training Rows of 10k
- Maximum Training Columns of 1k

Since we are in Beta, the above limits may change as we advance the solution forward. Keep an eye out for updates and feature additions as we respond to your feedback!

.. _dataset_upload:

Uploading
*********
A dataset can be uploaded from a local file on your computer using :meth:`Data.import_file<datarobotai.data.Data.import_file>`,
from a dataframe (`pandas.DataFrame`) using :meth:`Data.import_data_frame <datarobotai.data.Data.import_data_frame>` or from a URL using :meth:`Data.import_url <datarobotai.data.Data.import_url>`

.. code-block:: python

    import datarobotai.client as DataRobotAIClient
    import pandas as pd
    dr = DataRobotAIClient.create(key='<datarobot ai token>')

    # Uploading from a local file
    dataset1 = dr.data.import_url('/home/user/data/last_week_data.csv')
    dataset1.id
    >>> u'5c8aca35fb1fbe001d46acfe'

    # Uploading from URL
    dataset2 = dr.data.import_url('<insert_url_here>')

    # Uploading from pandas.DataFrame
    df = pd.read_csv('/home/user/data/last_week_data.csv')
    dataset3 = dr.data.import_data_frame(df.head(n=2000))

A dataset can also be uploaded directly to a project or at the start of a learning session using the :class:`Project <datarobotai.models.project.Project>` class.
See the :ref:`project <project_overview>` page for more information.

.. code-block:: python

    my_project = dr.projects.get_project('5c893a2003041f001cc00d94')

    # Uploaded to an existing project
    my_project.import_file('/home/user/data/sales_report_2018_A.csv')
    # Uploaded at the start of learn
    my_project.learn('/home/user/data/sales_report_2018_B.csv')


For large datasets, :meth:`start_import_file <datarobotai.data.Data.start_import_file>` and :meth:`start_import_url <datarobotai.data.Data.start_import_url>` can be used
to begin the upload process without blocking interaction with the API. See the :ref:`task <task_overview>` section for more information.

Retrieval
*********
Uploaded datasets can be accessed in multiple ways. To access an individual dataset use :meth:`Data.get <datarobotai.data.Data.get>`

.. code-block:: python

    dataset1 = dr.data.get('5c8aca35fb1fbe001d46acfe')
    dataset1.id
    >>> u'5c8aca35fb1fbe001d46acfe'
    dataset1.name
    >>> u'last_week_data.csv'

To retrieve a list of uploaded datasets associated with an account use
:meth:`Data.list <datarobotai.data.Data.list>`

.. code-block:: python

    # Returns a list of uploaded datasets
    dr.data.list()
    >>> ([Dataset(u'5c8aca35fb1fbe001d46acfe', u'last_week_data.csv', u'2019-03-14T21:40:05.973000Z'), Dataset(u'5c89536903041f001dc00d8b', u'1k_diabetes_simplified_features.csv', u'2019-03-13T19:00:57.789000Z')], 2)

    # Using the offset parameter, the first dataset is excluded from the results
    dr.data.list(offset=1)
    >>> ([Dataset(u'5c89536903041f001dc00d8b', u'1k_diabetes_simplified_features.csv', u'2019-03-13T19:00:57.789000Z')], 2)

    # Using the limits parameter, the number of datasets returned is limited to one
    dr.data.list(limit=1)
    >>> ([Dataset(u'5c8aca35fb1fbe001d46acfe', u'last_week_data.csv', u'2019-03-14T21:40:05.973000Z')], 2)

Where:

* ``offset`` indicates the number of results to skip. Defaults to 0.
* ``limit`` indicates the maximum number of datasets to return. Defaults to 0.

An existing :class:`project <datarobotai.models.project.Project>` can also access datasets using :meth:`get_datasets <datarobotai.models.project.Project.get_datasets>`.
To add a dataset to an existing project use :meth:`add_dataset <datarobotai.models.project.Project.add_dataset>`

.. code-block:: python

    dataset1 = dr.data.get('5c8aca35fb1fbe001d46acfe')
    my_project.get_datasets()
    >>> []
    my_project.add_dataset(dataset1)
    my_project.get_datasets()
    >>> [DatasetReference(id=u'5c8aca35fb1fbe001d46acfe', name=u'last_week_data.csv')]

See the :ref:`project <project_overview>` page for more information.

Deleting
********
Datasets can be deleted using :meth:`Data.delete <datarobotai.data.Data.delete>`

.. code-block:: python

    dataset_to_delete = dr.data.get('5c89536903041f001dc00d8b')
    len(dr.data.list()))
    >>> 2
    dr.data.delete(dataset_to_delete.id)
    len(dr.data.list())
    >>> 1

Note: If a dataset was added to a project or used in a learning session before being deleted, the project and
learning session will remain intact post deletion.