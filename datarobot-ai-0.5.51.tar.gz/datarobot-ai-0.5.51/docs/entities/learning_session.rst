.. _learning_session_overview:

################
Learning Session
################

A *learning session* is how a :ref:`project <project_overview>` learns how to predict an
:ref:`output <output_overview>`. A learning session will have a corresponding deployment that can be
used to make predictions. It can predict as soon as the first model tried by DataRobot AI API finishes;
however, it will continue to learn and improve its predictions in the background.

Making a New Learning Session
=============================
There are a few different similar interfaces for setting up a learning session.

The simplest way involves taking a previously set up
:py:class:`project <datarobotai.models.project.Project>` and invoking
:py:meth:`learn <datarobotai.models.project.Project.learn>`.

A learning session can be started from a local file, list of records or from a previously ingested
:py:class:`dataset <datarobotai.models.dataset.Dataset>`

.. code-block:: python

    import pandas as pd

    from datarobotai.client import DataRobotAIClient
    dr = DataRobotAIClient.create('my-API-token')

    ai = dr.create_project('My Project')
    ai.learn('target', '/path/to/my/file.csv')  # blocking call

    more_data = ai.import_file('/path/to/another/file.csv')
    ai.learn('target2', more_data.dataset_id)  # blocking call

    much_more_data = pd.DataFrame.from_csv('/path/to/another/file_2.csv').head(20000).to_dict('records')
    ai.learn('target3', much_more_data)  # blocking call

Note that :py:meth:`ai.learn <datarobotai.models.project.Project.learn>` will block until the data
has finished uploading and the learning session is ready to make predictions.  Once it has returned,
DataRobot AI API will continue trying to find better models in the background.

If you want to use the client without making blocking calls, use the following workflow:

.. code-block:: python

    ai = dr.create_project('My Project')

    file_import_task = dr.data.start_import_file('/path/to/my/file.csv')
    while not file_import_task.is_complete():
        do_something_else()
    dataset = file_import_task.get_result()  # blocks if not already done
    ai.add_dataset(dataset)

    learning_task = dr.learning.start_learn('target', dataset.dataset_id)
    while not learning_task.is_complete():
        do_something_else()
    session = learning_task.get_result()  # blocks if not already done
    ai.add_learning_session(learning_session, output_name=session.target)

Predicting with a Learning Session
==================================
If the learning session is the best or only way tried to learn a particular target, it makes
sense to make it the :ref:`output <output_overview>` of a project.  This is done automatically
when using :py:meth:`ai.learn <datarobotai.models.project.Project.learn>`, and can be done manually
with :py:meth:`ai.add_learning_session <datarobotai.models.project.Project.add_learning_session>`.

.. code-block:: python

    ai = dr.create_project('My Project')
    ai.add_learning_session(my_session, output_name='target')
    ai.predict('target', '/path/to/new/data.csv')

Alternatively, :ref:`predictions <prediction_overview>` can be made directly against a learning session
before tying it to an output to test it out.

.. code-block:: python

    session.predict('/path/to/new/data.csv')

It's expected that the predictions a learning session gives will shift after it first becomes able
to predict - predictions are available as soon as any model finishes, but DataRobot AI API will continue
looking for better models in the background.
