.. _list_overview:

#####
Lists
#####

When invoking a method that returns a list of objects, a wrapper class is placed on the list to
simplify interactions with the objects inside. As you may have more objects than would be wise
to return in a single response, the Paginator wrapper is used to provide an interface to abstract
away the multiple requests you would need to make to get all the data

.. code-block:: python

    from datarobotai.client import DataRobotAIClient
    dr = DataRobotAIClient.create(key='<datarobot ai token>')

    # A list of Project objects is returned through a Paginator
    projects = dr.projects.list()

    projects.total
    >>> 2

    list(projects)  # Iterating over all the projects, perhaps by using `list` will consum all of them
    >>> [Project(id=u'5c893a2003041f001cc00d94', name=u'Project Name 2'),
         Project(id=u'5c8ad49efb1fbe001746acfe', name=u'Project Name 1')])

Common methods used to interact with list objects are still available regardless of the wrapper.

.. code-block:: python

    my_project = list(dr.projects.list())[0]
    my_predictions = my_project.predict(target='readmitted', data='hospital_admission_data_predict.csv')

    # A list of Prediction objects is also returned with a Paginator
    my_predictions
    >>> Paginator(factory=PredictionFactory, total=6)

    list(my_predictions)
    >>> [
            Prediction(0, 0.0, [{u'value': 0.28593628, u'label': 1.0}, {u'value': 0.71406372, u'label': 0.0}]),
            Prediction(1, 0.0, [{u'value': 0.1934045734, u'label': 1.0}, {u'value': 0.8065954266, u'label': 0.0}]),
            Prediction(2, 1.0, [{u'value': 0.5243181362, u'label': 0.0}, {u'value': 0.4756818638, u'label': 1.0}]),
            Prediction(3, 0.0, [{u'value': 0.2126671305, u'label': 1.0}, {u'value': 0.7873328695, u'label': 0.0}]),
            Prediction(4, 1.0, [{u'value': 0.5701285404, u'label': 0.0}, {u'value': 0.4298714596, u'label': 1.0}]),
            Prediction(5, 0.0, [{u'value': 0.3586292389, u'label': 1.0}, {u'value': 0.6413707611, u'label': 0.0}]),
        ]
