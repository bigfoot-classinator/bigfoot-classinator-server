.. _output_overview:

######
Output
######

An *output* represents something an project has learned.
For example, a project around managing hospital resources might involve two outputs - "readmitted"
(whether a patient will be readmitted if they are discharged) and "length_of_stay"
(how long a patient should be expected to stay from their admit date).

Retrieval
*********
Outputs are created from :ref:`learning sessions <learning_session_overview>` and stored within a :ref:`project <project_overview>`.
To access outputs use :meth:`get_output <datarobotai.models.project.Project.get_output>`.

.. code-block:: python

    import datarobotai.client as DataRobotAIClient
    dr = DataRobotAIClient.create(key='<datarobot ai token>')
    my_project = dr.projects.get_project('5c8bdfac4ef741001b17de9c')
    >>> Project(id=u'5c8bdfac4ef741001b17de9c', name=u'My Project')

    # Outputs do not exist before a Learning Session is created
    my_project.get_output(output_target='readmitted')
    >>> []

    my_project.learn(target='readmitted', data_source='5c8be0a24ef741001817de9f')
    my_project.get_output(output_target='readmitted')
    >>> OutputList([Output(name=u'readmitted', target=u'readmitted', source={u'url': u'https://api.dragonpanda.drdev.io/predApi/v1.0/deployments/5c8be0e14ef741001c17dea2/predictions', u'deploymentId': u'5c8be0e14ef741001c17dea2', u'datarobot-key': u'9ea0449e-c2e5-4ea2-8885-0319da6ccf2b'})], 1)

Multiple outputs can be stored in one project. To access individual outputs use :meth:`get_output <datarobotai.models.project.Project.get_output>` and specify the ``output_target``.
For a list of all outputs associated with a project use :meth:`get_outputs <datarobotai.models.project.Project.get_outputs>`.

.. code-block:: python

    print len(my_project.get_outputs())
    >>> 1
    my_project.learn(target='length_of_stay', data_source='5c8be0a24ef741001817de9f')
    print len(my_project.get_outputs())
    >>> 2
    my_project.get_output('length_of_stay')
    >>> Output(name=u'time_in_hospital', target=u'length_of_stay', source={u'url': u'https://api.dragonpanda.drdev.io/predApi/v1.0/deployments/5c8bfc414ef741001c17dec5/predictions', u'deploymentId': u'5c8bfc414ef741001c17dec5', u'datarobot-key': u'9ea0449e-c2e5-4ea2-8885-0319da6ccf2b'})


Features
********
To view a list of features use ``get_features``. Providing at least one value for each feature is the minimum set required to use an output.

.. code-block:: python

    my_output = my_project.get_output('length_of_stay')
    my_output.get_features()
    >>> OutputFeatures([
            Feature(u'Categorical', u'admission_type_id'),
            Feature(u'Categorical', u'age'),
            Feature(u'Categorical', u'gender'),
            Feature(u'Categorical', u'insulin'),
            Feature(u'Numeric', u'num_lab_procedures'),
            Feature(u'Numeric', u'num_medications'),
            Feature(u'Numeric', u'num_procedures'),
            Feature(u'Numeric', u'number_inpatient'),
            Feature(u'Boolean', u'readmitted'),
            Feature(u'Numeric', u'length_of_stay')
        ])