.. _prediction_overview:

##########
Prediction
##########

Once you have built a model for your data, predictions can be used to test it and
ultimately deploy an application.

Creating Predictions
********************
Using the :ref:`project <project_overview>` class, predictions can be created and viewed with :meth:`predict <datarobotai.models.project.Project.predict>`.
Note that :ref:`outputs <output_overview>` for a :ref:`learning session <learning_session_overview>` must already exists prior to making predictions.

.. code-block:: python

    import datarobotai.client.DataRobotAIClient
    dr = DataRobotAIClient.create(key='<datarobot ai token>')
    my_project = dr.projects.get_project('5c8bdfac4ef741001b17de9c')

    # If no learning sessions exist an error will occur
    my_project.predict(target='readmitted', data='hospital_admission_data.csv')
    >>> 'Input error: No outputs were found for target readmitted on project 5c8bdfac4ef741001b17de9c. Have you trained a model by calling `learn`?'

    # A model must be trained before predictions can be made
    my_project.learn(target='readmitted', data_source='5c8be0a24ef741001817de9f')
    >>> Project(id=u'5c8fa61c7082a4001a984d9a', name=u'My Project')

    # Now predictions can be made against new data
    my_predictions = my_project.predict(target='readmitted', data='hospital_admission_data_predict.csv')
    print(my_predictions[0:5])
    >>> PredictionList([
            Prediction(0, 0.0, [{u'value': 0.28593628, u'label': 1.0}, {u'value': 0.71406372, u'label': 0.0}]),
            Prediction(1, 0.0, [{u'value': 0.1934045734, u'label': 1.0}, {u'value': 0.8065954266, u'label': 0.0}]),
            Prediction(2, 1.0, [{u'value': 0.5243181362, u'label': 0.0}, {u'value': 0.4756818638, u'label': 1.0}]),
            Prediction(3, 0.0, [{u'value': 0.2126671305, u'label': 1.0}, {u'value': 0.7873328695, u'label': 0.0}]),
            Prediction(4, 1.0, [{u'value': 0.5701285404, u'label': 0.0}, {u'value': 0.4298714596, u'label': 1.0}]),
            Prediction(5, 0.0, [{u'value': 0.3586292389, u'label': 1.0}, {u'value': 0.6413707611, u'label': 0.0}]),
        ])

Predictions returned from ``predict`` will include the following:
    * ``row`` : the row number of the prediction data
    * ``prediction`` : the result of a prediction (either the predicted class for classification or the predicted value for regression)
    * ``values`` : details on the prediction (i.e. the probability of each label for classification, etc.)

Using Predictions
*****************
During the evaluation of predictions, :meth:`score_for <datarobotai.models.prediction.Prediction.score_for>` can be used to retrieve the model output for the specified class label.

.. code-block:: python

    # Classification project with 3 possible outcomes: positive, neutral, negative
    project.learn(target='airline_sentiment', data_source='flight_experience_train.csv')
    predictions = project.predict(target='airline_sentiment', data='flight_experience_predict.csv')

    # Results for all 3 possible outcomes are returned
    print (predictions[0])
    >>> Prediction(0, u'negative', [{u'value': 0.0144251245, u'label': u'positive'}, {u'value': 0.2283681375, u'label': u'neutral'}, {u'value': 0.757206738, u'label': u'negative'}])

    # Breakdown for each possible classification
    predictions[0].score_for('positive')
    >>> 0.0144251245
    predictions[0].score_for('negative')
    >>> 0.757206738
    predictions[0].score_for('neutral')
    >>> 0.2283681375
