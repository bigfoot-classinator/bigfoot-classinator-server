.. _project_overview:

#######
Project
#######

A *project* is the fundamental organizational unit in DataRobot AI API.
It represents a collection of work to solve a business problem,
for example, a bank may create a project to understand the credit-worthiness of their customers.
Projects incorporate many of the other fundamental objects, especially :ref:`datasets <dataset_overview>`,
:ref:`learning sessions <learning_session_overview>`, and :ref:`outputs <output_overview>`.

A project can also be called an *AI*, because it learns from past data to predict on new data.

Quick Reference
===============
The following code block summarizes the basic interactions with projects.

.. code-block:: python

    import datarobotai.client.DataRobotAIClient
    dr = DataRobotAIClient.create(key='<datarobot ai token>')
    ai = dr.create_ai('My AI')
    ai.learn('credit_risk', 'training_data.csv')
    predictions = ai.predict('credit_risk', 'prediction_data.csv')


Creating a Project
******************
A project can be created using :meth:`ProjectClient.create_project <datarobotai.projects.ProjectClient.create_project>`

.. code-block:: python

    import datarobotai.client.DataRobotAIClient
    dr = DataRobotAIClient.create(key='<datarobot ai token>')

    my_project = dr.projects.create_project('Project Name 1')
    my_project.id
    >>> u'5c8ad49efb1fbe001746acfe'
    my_project.name
    >>> u'Project Name 1'

Or a project can be created using ``create_ai``
(see the note above the "Quick Reference" section)

.. code-block:: python

    ai_project = dr.create_ai('Project Name 2')
    ai_project.name
    >>> u'Project Name 2'
    dr.projects.list()
    >>> ProjectList([
            Project(id=u'5c893a2003041f001cc00d94', name=u'Project Name 2'),
            Project(id=u'5c8ad49efb1fbe001746acfe', name=u'Project Name 1')], 2)

Interacting with a Project
**************************
Projects provide a way to organize uploaded :ref:`datasets <dataset_overview>` and store :ref:`learning sessions <learning_session_overview>`.
A dataset can be uploaded and added to an existing project using :meth:`import_file <datarobotai.models.project.Project.import_file>`, :meth:`import_data_frame <datarobotai.models.project.Project.import_data_frame>`
or :meth:`import_url <datarobotai.models.project.Project.import_url>`. :ref:`See here <dataset_size_limits>` for file size limitations.
Alternatively, existing datasets can be added to a project using :meth:`add_dataset <datarobotai.models.project.Project.add_dataset>`.

.. code-block:: python

    dataset = dr.data.get('5c8aca35fb1fbe001d46acfe')
    my_project.add_dataset(dataset)
    my_project.get_datasets()
    >>> [DatasetReference(id=u'5c8aca35fb1fbe001d46acfe', name=u'last_week_data.csv')]

    # Option to import a dataset and add it to the project
    my_project.import_file('lendingdata_2018.csv')
    print (len(my_project.get_datasets()))
    >>> 2

A :ref:`learning sessions <learning_session_overview>` to train your model can be created using :meth:`learn <datarobotai.models.project.Project.learn>`.
To add an existing learning session to a project use :meth:`add_learning_session <datarobotai.models.project.Project.add_learning_session>`.

.. code-block:: python

    import pandas as pd

    target = 'readmitted'
    filepath = '/home/user/data/hospital_stats_train.csv'
    dataset_id = '5c89536903041f001dc00d8b'
    records = pd.DataFrame.from_csv(filepath).head(2000).to_dict('records')
    # Use dataset_id to create a learning session from an existing dataset
    my_project.learn(target=target, data_source=dataset_id)
    # Use filepath to upload a new dataset during learning session creation
    my_project.learn(target=target, data_source=file_path)
    # Use a list of dicts converted from pandas.DataFrame to upload a new dataset during learning session creation
    my_project.learn(target=target, data_source=records)
    print len(my_project.get_learning_sessions())
    >>> 3

Where:

* ``target`` is the name of the selected target feature to predict on
* ``data_source`` is the data for model training. It can be a path to a local file, an id of an uploaded dataset or a list of records produced by `DataFrame.to_dict` with `orient='records'` parameter.

An :ref:`output <output_overview>` represents something a project has learned. To access individual outputs use :meth:`get_output <datarobotai.models.project.Project.get_output>` specifying the ``output_target``.
For a list of all outputs use :meth:`get_outputs <datarobotai.models.project.Project.get_outputs>`.

.. code-block:: python

    my_project.get_outputs()
    >>> OutputList([Output(name=u'readmitted', target=u'readmitted', source={u'url': u'https://api.dragonpanda.drdev.io/predApi/v1.0/deployments/5c8be0e14ef741001c17dea2/predictions', u'deploymentId': u'5c8be0e14ef741001c17dea2', u'datarobot-key': u'9ea0449e-c2e5-4ea2-8885-0319da6ccf2b'})], 1)

After a model has been trained to learn an output, :ref:`predictions <prediction_overview>` can be made on a target and dataset
using :class:`predict <datarobotai.models.project.Project.predict>`. See the :ref:`prediction <prediction_overview>` page for more information.

.. code-block:: python

    target = 'readmitted'
    data = '/home/user/data/hospital_stats_predict.csv'
    my_predictions = my_project.predict(target=target, data=data)
    print(my_predictions[0:5])
    >>> PredictionList([
            Prediction(0, 0.0, [{u'value': 0.28593628, u'label': 1.0}, {u'value': 0.71406372, u'label': 0.0}]),
            Prediction(1, 0.0, [{u'value': 0.1934045734, u'label': 1.0}, {u'value': 0.8065954266, u'label': 0.0}]),
            Prediction(2, 1.0, [{u'value': 0.5243181362, u'label': 0.0}, {u'value': 0.4756818638, u'label': 1.0}]),
            Prediction(3, 0.0, [{u'value': 0.2126671305, u'label': 1.0}, {u'value': 0.7873328695, u'label': 0.0}]),
            Prediction(4, 1.0, [{u'value': 0.5701285404, u'label': 0.0}, {u'value': 0.4298714596, u'label': 1.0}]),
            Prediction(5, 0.0, [{u'value': 0.3586292389, u'label': 1.0}, {u'value': 0.6413707611, u'label': 0.0}]),
        ])