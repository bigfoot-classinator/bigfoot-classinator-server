.. _task_overview:

####
Task
####

When you upload data, or start learning an output you will need to wait for the
process to complete. Depending on the operation, it might take a less than a
second, or up to several minutes. In order to monitor these long-running
processes, we provide a *task* identifier in the response when starting certain
operations. This identifier is provided to the API to check the status of the
task. Once a task is complete, the next request to check the status indicates
the task is complete, and gives the URL to access the data associated with the
completed task.

Task Status
***********
To check the current state of a task use ``status``. A task may return any one of the following statuses:
    * INITIALIZED - The task has been accepted but has not started
    * RUNNING - The task is actively being worked on
    * ERROR - The task did not complete due to an error
    * ABORTED - The task did not complete because it was requested to be stopped
    * COMPLETED - The task is complete

In addition, :meth:`is_successful <datarobotai.task.Task.is_successful>` can be used to return if a task was accepted and :meth:`is_complete <datarobotai.task.Task.is_complete>` can be used to
return when a task is finished.

.. code-block:: python

    my_task = dr.data.start_import_file(file_path='fastiron-train-sample.csv')
    my_task.is_successful()
    >>> True
    my_task.is_complete()
    >>> False

Once a task is finished processing, use :meth:`get_result <datarobotai.task.Task.get_result>` to retrieve the outcome.
Note, this is a blocking call for tasks that are not yet complete. If you wish to set the amount of seconds to wait before giving up on an operation use a ``timeout`` parameter.

.. code-block:: python

    my_task.get_result(timeout=10)
    >>> Dataset(u'5c8fed769fc8e6001ec6162e', u'fastiron-train-sample.csv', u'2019-03-18T19:11:50.598000Z')

