###############
Getting Started
###############

Installation
============
You will need the following

- Python 2.7, 3.5, or 3.6
- pip
- DataRobot AI tar file *(available from the Python client page)*
- DataRobot AI API Key *(see the API Key Management page from your DataRobot AI account)*

The tar file is able to be installed using `pip` or the newer `pipenv`.

.. code-block:: bash

    $ pip install datarobot-ai-<version>.tar.gz

Configuration
=============
Once the client is installed and you have an API Key, the first step is to create an instance of  :class:`DataRobot AI Client <datarobotai.client.DataRobotAIClient>`.
Note that your credentials can be explicitly provided to the client in code or through an environment variable named `DATAROBOTAI_API_KEY`.

.. code-block:: python

   import datarobotai.client.DataRobotAIClient
   dr = DataRobotAIClient.create(key='<datarobot ai token>')

