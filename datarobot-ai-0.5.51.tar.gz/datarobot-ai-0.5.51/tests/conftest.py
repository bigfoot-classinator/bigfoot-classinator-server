import pytest


@pytest.fixture
def datarobotai_client():
    from datarobotai.client import DataRobotAIClient

    client = DataRobotAIClient.create(endpoint='http://example.com',
                                      key='a-key')

    return client


@pytest.fixture
def dataset_data():
    return dict(id='123',
                datasetName='A dataset name',
                createdOn='2019-02-14T12:34:56.000Z',
                )


@pytest.fixture()
def sample_dataset_list(dataset_data):
    return {'total': 1, 'data': [dataset_data]}


@pytest.fixture
def sample_learning_session():
    return {
        'id': 'tango',
        'datasetVersionId': 'sierra',
        'datasetId': '1',
        'name': 'uniform',
        'target': 'romeo',
        'created': 'NOW',
        'links': {
            'self': 'http://example.com/learningSessions/tango/',
            'status': 'http://example.com/status/foobar-completed'
        }
    }


@pytest.fixture
def sample_learning_session_list(sample_learning_session):
    return {'total': 2, 'data': [sample_learning_session, sample_learning_session]}


@pytest.fixture
def request_grabber():
    """
    An `additional_matcher` that can be used with requests_mock to just grab every request
    for later introspection
    """

    class Grabber(object):
        def __init__(self):
            self.requests = []

        def __call__(self, request):
            self.requests.append(request)
            return True

    return Grabber()
