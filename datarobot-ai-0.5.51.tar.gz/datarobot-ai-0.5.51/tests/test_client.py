import re

import pytest
from mock import patch
from requests.adapters import Retry

from datarobotai.client import DataRobotAIClient
from datarobotai import __version__
from datarobotai.http_client import RESTClientObject, DEFAULT_CONNECT_TIMEOUT


def test_client_accepts_key():
    client = DataRobotAIClient.create(key='alpha-beta')
    assert client.session.token == 'alpha-beta'


def test_client_accepts_uri():
    client = DataRobotAIClient.create(key='key', endpoint='https://api.staging.dragonpanda.net')
    assert client.session.endpoint == 'https://api.staging.dragonpanda.net'


def test_client_accepts_authorization_type_bearer():
    client = DataRobotAIClient.create(authorization_type='Bearer',
                                      key='foo')
    assert client.session.headers['Authorization'] == 'Bearer foo'


def test_client_will_fail_fast_with_bad_auth_scheme():
    with pytest.raises(ValueError):
        DataRobotAIClient.create(authorization_type='Fubar',
                                 key='foo')


def test_client_str_is_good():
    client = DataRobotAIClient.create(key='foobar',
                                      endpoint='some://url',
                                      authorization_type='Bearer')
    str_template = r"DataRobotAIClient version \S+ connecting to 'some://url'"
    assert re.match(str_template, str(client))


class TestRestClient(object):

    def test_instantiation(self):
        """
        Basic client installation.
        """
        RESTClientObject(token='t-token',
                         endpoint='https://host_name.com',
                         authorization_type='Bearer')

    def test_recognizing_domain_on_instance(self):

        client = RESTClientObject(token='token',
                                  endpoint='https://host_name.com/api/v2')
        assert client.domain == 'https://host_name.com'

    def test_client_from_codeline(self):
        c = RESTClientObject(token='some_token',
                             endpoint='https://endpoint.com')

        assert c.token == 'some_token'
        assert c.endpoint == 'https://endpoint.com'
        assert c.connect_timeout == DEFAULT_CONNECT_TIMEOUT
        assert c.adapters
        for adapter in c.adapters.values():
            assert adapter.max_retries.connect > 0
            assert adapter.max_retries.method_whitelist == ['GET']

    def test_client_from_codeline_set_timeout(self):
        connect_timeout = 55
        c = RESTClientObject(token='some_token',
                             endpoint='https://endpoint.com',
                             connect_timeout=connect_timeout)
        assert c.connect_timeout == connect_timeout

    def test_client_from_codeline_max_retries(self):
        c = RESTClientObject(token='some token',
                             endpoint='https://endpoint.com',
                             max_retries=Retry(read=3, connect=3))
        assert c.adapters
        for adapter in c.adapters.values():
            assert adapter.max_retries.read == 3
            assert adapter.max_retries.connect == 3

    def test_client_user_agent(self):

        with patch('platform.system') as mock_system, \
             patch('platform.release') as mock_release, \
             patch('platform.machine') as mock_machine, \
             patch('platform.python_version') as mock_py_version:

            mock_system.return_value = 'Prince'
            mock_release.return_value = 'Party'
            mock_machine.return_value = 'x19_99'
            mock_py_version.return_value = 'yolo'
            client = RESTClientObject(endpoint='https://example.com')
            header = client.user_agent_header
        expected_agent = 'DataRobotAI-Python-Client/{} (Prince Party x19_99) Python-yolo'.format(
            __version__)
        assert header == {'User-Agent': expected_agent}

    def test_client_user_agent_with_suffix(self):
        suffix = "Blamo/8.23 (6.30)"
        orig = RESTClientObject(endpoint='https://example.com')
        with_suffix = RESTClientObject(endpoint='https://example.com',
                                       user_agent_suffix=suffix)
        assert with_suffix.user_agent_header['User-Agent'].startswith(
            orig.user_agent_header['User-Agent'])
        assert with_suffix.user_agent_header['User-Agent'].endswith(' ' + suffix)
