# - *- coding: utf- 8 - *-

from __future__ import unicode_literals

import pandas as pd
import pytest

from datarobotai.data import Data
from datarobotai.http_client import ClientError, ServerError
from datarobotai.models.project import Project


@pytest.fixture
def sample_data_source():
    return {
        'source': [
            {'壮': 1, 'val_1': 12, 'val_2': '🐍', 1: True, 'val_4': None},
            {'壮': 1, 'val_1': 13, 'val_2': 'тест', 1: False, 'val_4': None},
            {'壮': 1, 'val_1': 14, 'val_2': '壮语', 1: True, 'val_4': None},
        ],
        'encoded': [
            {'1': True, 'val_1': 12, 'val_2': '🐍', 'val_4': '', '壮': 1},
            {'1': False, 'val_1': 13, 'val_2': 'тест', 'val_4': '', '壮': 1},
            {'1': True, 'val_1': 14, 'val_2': '壮语', 'val_4': '', '壮': 1},
        ]
    }


@pytest.mark.parametrize('auth_type', ['Bearer'])
def test_dataset_client_uses_client_headers(requests_mock,
                                            datarobotai_client,
                                            sample_dataset_list,
                                            auth_type):
    datarobotai_client.session.set_auth(auth_type)

    assert auth_type in datarobotai_client.session.headers['Authorization']

    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/?offset=0&limit=50',
        request_headers=datarobotai_client.session.headers,
        headers={'content-type': 'application/json'},
        json=sample_dataset_list)

    ds = Data(datarobotai_client)
    ds.list()


def test_dataset_list(requests_mock, sample_dataset_list, datarobotai_client):
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/?offset=0&limit=50',
        headers={'content-type': 'application/json'},
        json=sample_dataset_list)

    ds = Data(datarobotai_client)

    result = ds.list()

    assert result.total == 1
    assert len(result) == 1


def test_dataset_list_with_params(requests_mock, sample_dataset_list, datarobotai_client):
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/?offset=1&limit=10',
        headers={'content-type': 'application/json'},
        json=sample_dataset_list)

    ds = Data(datarobotai_client)

    result = ds.list(offset=1, limit=10)

    assert result.total == 1
    assert len(result) == 1


def test_dataset_list_for_project(requests_mock, request_grabber,
                                  sample_dataset_list, datarobotai_client):
    project_id = 'deadbeefdeadbeef43211234'
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/?projectId=deadbeefdeadbeef43211234&offset=0&limit=50',
        headers={'content-type': 'application/json'},
        json=sample_dataset_list,
        additional_matcher=request_grabber
    )

    ds = Data(datarobotai_client)
    data_result = ds.list(project_id=project_id)

    proj = Project(project_id, 'My Proj', 0, 0, 0, datarobotai_client)
    proj_result = proj.get_datasets()

    for i, result in enumerate([data_result, proj_result]):
        assert result.total == 1
        assert len(result) == 1

        request_query = request_grabber.requests[i].qs
        assert request_query['projectid'][0]


def test_dataset_get(requests_mock, dataset_data, datarobotai_client):
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/echo-foxtrot',
        headers={'content-type': 'application/json'},
        json=dataset_data)

    ds = Data(datarobotai_client)

    result = ds.get('echo-foxtrot')

    assert result.dataset_id == dataset_data['id']
    assert result.id == result.dataset_id
    assert result.name == dataset_data['datasetName']
    assert result.created_on == dataset_data['createdOn']


def test_dataset_get_not_found_raises_error(requests_mock, datarobotai_client):
    requests_mock.register_uri('GET', 'http://example.com/datasets/abc123', status_code=404)

    ds = Data(datarobotai_client)

    with pytest.raises(ClientError) as error:
        ds.get('abc123')

    assert error.value.status == 404


def test_dataset_import_data_frame(requests_mock, datarobotai_client, dataset_data):
    def match_file(request):
        sent_csv_df = pd.read_csv(request.text.fields['file'][1]).fillna('')
        expected_df = pd.read_csv('tests/some-file.csv')
        return sent_csv_df.to_string() == expected_df.to_string()
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/fileImports/',
        status_code=202,
        additional_matcher=match_file,
        json={'links': {'result': 'http://example.com/status/foobar'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar',
        status_code=200,
        json={
            'status': 'COMPLETED',
            'message': '',
            'links':
                {'result': 'http://example.com/datasets/123'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/123',
        status_code=200,
        json=dataset_data
    )

    ds = Data(datarobotai_client)
    input_data_frame = pd.read_csv('tests/some-file.csv')
    result = ds.import_data_frame(input_data_frame)

    assert result.name == 'A dataset name'


def test_dataset_import_file(requests_mock, datarobotai_client, dataset_data):
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/fileImports/',
        status_code=202,
        json={'links': {'result': 'http://example.com/status/foobar'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar',
        status_code=200,
        json={
            'status': 'COMPLETED',
            'message': '',
            'links':
                {'result': 'http://example.com/datasets/123'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/123',
        status_code=200,
        json=dataset_data

    )

    ds = Data(datarobotai_client)
    result = ds.import_file('tests/some-file.csv')

    assert result.name == 'A dataset name'


def test_dataset_import_data_source(requests_mock, datarobotai_client, sample_data_source, dataset_data):
    def match_file(request):
        sent_csv_df = pd.read_csv(request.text.fields['file'][1], encoding='utf-8').fillna('')
        expected_df = pd.DataFrame(sample_data_source['encoded'])
        return sent_csv_df.sort_index(axis=1).equals(expected_df.sort_index(axis=1))
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/fileImports/',
        status_code=202,
        additional_matcher=match_file,
        json={'links': {'result': 'http://example.com/status/foobar'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar',
        status_code=200,
        json={
            'status': 'COMPLETED',
            'message': '',
            'links': {'result': 'http://example.com/datasets/123'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/123',
        status_code=200,
        json=dataset_data
    )
    ds = Data(datarobotai_client)
    result = ds.import_list_of_records(data_source=sample_data_source['source'])

    assert result.name == 'A dataset name'


def test_dataset_import_bytes_data_source(requests_mock, datarobotai_client, dataset_data):
    sent_data_source = [{'тест'.encode('utf-8'): 1, 'field_2': 'val'}]
    expected_data_source = [{'тест': 1, 'field_2': 'val'}]

    def match_file(request):
        sent_csv_df = pd.read_csv(request.text.fields['file'][1], encoding='utf-8').fillna('')
        expected_df = pd.DataFrame(expected_data_source)
        return sent_csv_df.sort_index(axis=1).equals(expected_df.sort_index(axis=1))
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/fileImports/',
        status_code=202,
        additional_matcher=match_file,
        json={'links': {'result': 'http://example.com/status/foobar'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar',
        status_code=200,
        json={
            'status': 'COMPLETED',
            'message': '',
            'links': {'result': 'http://example.com/datasets/123'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/123',
        status_code=200,
        json=dataset_data
    )
    ds = Data(datarobotai_client)
    result = ds.import_list_of_records(data_source=sent_data_source)

    assert result.name == 'A dataset name'


def test_dataset_import_url(requests_mock, datarobotai_client, dataset_data):
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/urlImports/',
        status_code=202,
        json={'links': {'result': 'http://example.com/status/foobar'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar',
        status_code=200,
        json={
            'status': 'COMPLETED',
            'message': '',
            'links':
                {'result': 'http://example.com/datasets/123'}})
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/123',
        status_code=200,
        json=dataset_data

    )

    ds = Data(datarobotai_client)
    result = ds.import_url('http://example.com/echo/xray')

    assert result.name == 'A dataset name'


def test_dataset_import_error(requests_mock, datarobotai_client):
    requests_mock.register_uri(
        'POST',
        'http://example.com/datasets/fileImports/',
        status_code=500)

    ds = Data(datarobotai_client)

    with pytest.raises(ServerError) as error:
        ds.import_file('tests/some-file.csv')

    assert error.value.url == 'http://example.com/datasets/fileImports/'
    assert error.value.status == 500


def test_dataset_delete_success(requests_mock, datarobotai_client):
    dataset_id = 'my-dataset-id'

    requests_mock.register_uri(
        'DELETE',
        'http://example.com/datasets/{}/'.format(dataset_id),
        status_code=204
    )

    ds = Data(datarobotai_client)
    ds.delete(dataset_id)


def test_dataset_delete_failure(requests_mock, datarobotai_client):
    dataset_id = 'my-dataset-id'

    requests_mock.register_uri(
        'DELETE',
        'http://example.com/datasets/{}/'.format(dataset_id),
        status_code=422
    )

    ds = Data(datarobotai_client)

    with pytest.raises(ClientError):
        ds.delete(dataset_id)


def test_dataset_eq(requests_mock, datarobotai_client, dataset_data):
    requests_mock.register_uri(
        'GET',
        'http://example.com/datasets/echo-foxtrot',
        headers={'content-type': 'application/json'},
        json=dataset_data)

    ds = Data(datarobotai_client)

    dataset_one = ds.get('echo-foxtrot')
    dataset_two = ds.get('echo-foxtrot')

    assert dataset_one == dataset_two
