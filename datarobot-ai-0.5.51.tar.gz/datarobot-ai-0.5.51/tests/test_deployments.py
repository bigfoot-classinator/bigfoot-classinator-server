import pytest

from datarobotai.models.deployment import Deployment


class TestDeployment(object):

    @pytest.fixture
    def deployment_data(self):
        data = {
            'url': 'http://server.net/',
            'datarobot-key': 'a-server-key',
            'deploymentId': '123',
            'foo': 'bar'
        }
        return data

    def test_not_broken_if_new_server_data(self, deployment_data):
        Deployment.from_server(deployment_data)

    def test_deployment_eq(self, deployment_data):
        d_one = Deployment.from_server(deployment_data)
        d_two = Deployment.from_server(deployment_data)
        assert d_one == d_two
