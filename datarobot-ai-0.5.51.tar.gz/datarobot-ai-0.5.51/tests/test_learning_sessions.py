import json

import pytest

from datarobotai.http_client import ClientError
from datarobotai.learning_sessions import LearningSessions
from datarobotai.models.learning_session import LearningSession


@pytest.fixture
def sample_features():
    return {
        'id': 'tango',
        'target': 'credit_risk',
        'datasetId': 'sierra',
        'features': [{
            'type': 'Numeric',
            'name': 'Credit_Amount'
        }, {
            'type': 'Categorical',
            'name': 'credit_risk'
        }]
    }


@pytest.fixture
def sample_deployment():
    return {
        'url': 'http://predserver.net/',
        'datarobot-key': 'secure-bits',
        'deploymentId': '123'
    }


@pytest.fixture
def sample_predictions():
    return {
        'data': [{
            'rowId': 0,
            'prediction': 'alpha',
            'predictionValues': [{
                'value': 0.49,
                'label': 'beta'
            }, {
                'value': 0.51,
                'label': 'alpha'
            }]
        }, {
            'rowId': 1,
            'prediction': 'beta',
            'predictionValues': [{
                'value': 0.49,
                'label': 'alpha'
            }, {
                'value': 0.51,
                'label': 'beta'
            }]
        }]
    }


@pytest.fixture
def sample_status():
    return {
        "status": "COMPLETED",
        "code": 0,
        "description": "",
        "links": {
            "self": "http://example.com/aiapi/status/foobar",
            "result": "http://example.com/aiapi/learningSessions/tango/"
        },
        "created": "NOW",
        "message": "",
        "statusType": "",
        "statusId": "foobar",
    }


@pytest.mark.parametrize('auth_type', ['Bearer'])
def test_learning_session_client_uses_client_headers(requests_mock,
                                                     datarobotai_client,
                                                     sample_learning_session,
                                                     auth_type):
    datarobotai_client.session.set_auth(auth_type)

    assert auth_type in datarobotai_client.session.headers['Authorization']

    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        request_headers=datarobotai_client.session.headers,
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    ams = LearningSessions(datarobotai_client)
    ams.get('tango')


def test_learning_session_get(requests_mock, datarobotai_client, sample_learning_session):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    ams = LearningSessions(datarobotai_client)

    result = ams.get('tango')

    assert result.learning_session_id == 'tango'
    assert result.id == result.learning_session_id
    assert result.dataset_id == '1'
    assert result.name == 'uniform'
    assert result.target == 'romeo'
    assert result.created_on == 'NOW'


def test_learning_session_eq(requests_mock, datarobotai_client, sample_learning_session):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    ls_client = LearningSessions(datarobotai_client)

    learning_session_one = ls_client.get('tango')
    learning_session_two = ls_client.get('tango')
    assert learning_session_one == learning_session_two


def test_learning_session_get_features(requests_mock, datarobotai_client, sample_features):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/features/',
        headers={'content-type': 'application/json'},
        json=sample_features)

    ams = LearningSessions(datarobotai_client)

    def assert_features(result):
        assert result.learning_session_id == 'tango'
        assert result.dataset_id == 'sierra'
        assert result.target == 'credit_risk'
        assert len(result.feature_list) == 2
        for res, feature in zip(result, sample_features['features']):
            assert res.name == feature['name']
            assert res.feature_type == feature['type']

    features = ams.get_features('tango')

    assert_features(features)

    learningSessionObject = LearningSession(sample_features['id'],
                                            None, None, None, None,
                                            datarobotai_client, None)

    features = learningSessionObject.get_features()
    assert_features(features)


def test_learning_session_get_not_found_raises_error(requests_mock, datarobotai_client):
    requests_mock.register_uri('GET',
                               'http://example.com/learningSessions/abc123/',
                               status_code=404)

    ams = LearningSessions(datarobotai_client)

    with pytest.raises(ClientError) as error:
        ams.get('abc123')

    assert error.value.status == 404


def test_learning_session_learn(requests_mock, datarobotai_client):
    def match_request_body(request):
        return json.loads(request.text) == {'datasetId': 'a-dataset', 'target': 'a-target'}

    requests_mock.register_uri(
        'POST',
        'http://example.com/learningSessions/',
        status_code=202,
        json={'links': {'result': 'http://example.com/status/foobar'}},
        additional_matcher=match_request_body)

    ams = LearningSessions(datarobotai_client)

    result = ams.start_learn('a-target', 'a-dataset')

    assert result.task_url == 'http://example.com/status/foobar'


def test_learning_sessions_wait_for_training_complete(requests_mock, datarobotai_client,
                                                      sample_learning_session, sample_status):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar-completed',
        headers={'content-type': 'application/json'},
        json=sample_status)

    ams = LearningSessions(datarobotai_client)

    result = ams.wait_for_training_complete(sample_learning_session['id'])
    assert result.learning_session_id == 'tango'
    assert result.id == result.learning_session_id
    assert result.dataset_id == '1'
    assert result.name == 'uniform'
    assert result.target == 'romeo'
    assert result.created_on == 'NOW'


def test_learning_session_model_wait_for_training_complete(requests_mock, datarobotai_client,
                                                           sample_learning_session, sample_status):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar-completed',
        headers={'content-type': 'application/json'},
        json=sample_status)

    ams = LearningSession.from_server(sample_learning_session, datarobotai_client)

    result = ams.wait_for_training_complete()
    assert result.learning_session_id == 'tango'
    assert result.id == result.learning_session_id
    assert result.dataset_id == '1'
    assert result.name == 'uniform'
    assert result.target == 'romeo'
    assert result.created_on == 'NOW'


def test_learning_session_model_start_complete_training(requests_mock, datarobotai_client,
                                                        sample_learning_session, sample_status):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    requests_mock.register_uri(
        'GET',
        'http://example.com/status/foobar-completed',
        headers={'content-type': 'application/json'},
        json=sample_status)

    ams = LearningSession.from_server(sample_learning_session, datarobotai_client)

    result = ams.start_complete_training().get_result()
    assert result.learning_session_id == 'tango'
    assert result.id == result.learning_session_id
    assert result.dataset_id == '1'
    assert result.name == 'uniform'
    assert result.target == 'romeo'
    assert result.created_on == 'NOW'


def test_learning_session_learn_error(requests_mock, datarobotai_client):
    requests_mock.register_uri('POST', 'http://example.com/learningSessions/', status_code=403)

    ams = LearningSessions(datarobotai_client)

    with pytest.raises(ClientError) as error:
        ams.learn('a-dataset', 'a-target')

    assert error.value.url == 'http://example.com/learningSessions/'
    assert error.value.status == 403


def test_learning_session_list(requests_mock, datarobotai_client, sample_learning_session_list):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/?offset=0&limit=50',
        headers={'content-type': 'application/json'},
        json=sample_learning_session_list)

    ams = LearningSessions(datarobotai_client)

    result = ams.list()

    assert result.total == 2
    assert len(result) == 2


def test_get_learning_sessions_for_project(requests_mock, datarobotai_client,
                                           sample_learning_session_list):
    project_id = '1'
    requests_mock.register_uri('GET', 'http://example.com/learningSessions/?projectId=1',
                               headers={'content-type': 'application/json'},
                               json=sample_learning_session_list)

    sessions = datarobotai_client.projects.get_learning_sessions(project_id)

    assert sessions.total == 2
    assert len(sessions) == 2
    first = list(sessions)[0]
    assert isinstance(first, LearningSession)


def test_get_learning_sessions_for_project_with_params(requests_mock, datarobotai_client,
                                                       sample_learning_session_list):
    project_id = '1'
    offset, limit = 2, 8
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/?projectId=1&offset={}&limit={}'.format(offset, limit),
        headers={'content-type': 'application/json'},
        json=sample_learning_session_list)

    sessions = datarobotai_client.projects.get_learning_sessions(project_id,
                                                                 offset=offset, limit=limit)

    assert sessions.total == 2
    assert len(sessions) == 2
    first = list(sessions)[0]
    assert isinstance(first, LearningSession)


def test_learning_session_delete_success(requests_mock, datarobotai_client):
    session_id = 'my-session-id'

    requests_mock.register_uri(
        'DELETE',
        'http://example.com/learningSessions/{}/'.format(session_id),
        status_code=204
    )

    ams = LearningSessions(datarobotai_client)
    ams.delete(session_id)


def test_learning_session_delete_failure(requests_mock, datarobotai_client):
    session_id = 'my-session-id'

    requests_mock.register_uri(
        'DELETE',
        'http://example.com/learningSessions/{}/'.format(session_id),
        status_code=422
    )

    ams = LearningSessions(datarobotai_client)

    with pytest.raises(ClientError):
        ams.delete(session_id)
        ams.delete(session_id)


def test_learning_session_model_can_predict(requests_mock,
                                            datarobotai_client,
                                            sample_learning_session,
                                            sample_deployment,
                                            sample_predictions):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/deployment/',
        headers={'content-type': 'application/json'},
        json=sample_deployment)

    requests_mock.register_uri(
        'POST',
        'http://predserver.net/',
        status_code=200,
        headers={'content-type': 'application/json'},
        json=sample_predictions)

    ams = LearningSessions(datarobotai_client)

    model = ams.get('tango')

    result = model.predict('tests/some-file.csv')

    assert len(result) == 2


def test_learning_session_predict_json(requests_mock,
                                       datarobotai_client,
                                       sample_learning_session,
                                       sample_deployment,
                                       sample_predictions,
                                       request_grabber):
    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/',
        headers={'content-type': 'application/json'},
        json=sample_learning_session)

    requests_mock.register_uri(
        'GET',
        'http://example.com/learningSessions/tango/deployment/',
        headers={'content-type': 'application/json'},
        json=sample_deployment)

    requests_mock.register_uri(
        'POST',
        'http://predserver.net/',
        status_code=200,
        headers={'content-type': 'application/json'},
        json=sample_predictions,
        additional_matcher=request_grabber
    )

    ams = LearningSessions(datarobotai_client)

    model = ams.get('tango')

    model.predict({'foo': 1})

    assert request_grabber.requests[0].headers['Content-Type'] == 'application/json'
