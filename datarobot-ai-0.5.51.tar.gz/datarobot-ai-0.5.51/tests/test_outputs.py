import pytest

from datarobotai.models.output import Output, OutputFeatures


@pytest.fixture
def output_server_data():
    return {'name': 'abc',
            'target': 'hello',
            'source': {
                'url': 'http://server.net/',
                'datarobot-key': 'a-server-key',
                'deploymentId': '123',
            }}


class TestOutput(object):

    @pytest.fixture
    def feature_data(self):
        return {
            'features': [
                {'name': 'col1', 'type': 'Categorical'},
                {'name': 'col2', 'type': 'Numeric'},
            ]
        }

    def test_not_broken_if_new_server_data(self, output_server_data):
        data = dict(output_server_data, newKey='someNewValue')
        Output.from_server(None, data, None)

    def test_get_outputs(self, datarobotai_client, requests_mock, output_server_data):
        expected = {
            'total': 1,
            'data': [output_server_data],
            'links': {'next': None, 'previous': None}
        }
        requests_mock.register_uri('GET', 'http://example.com/projects/1/outputs/',
                                   headers={'content-type': 'application/json'}, json=expected)

        outputs = datarobotai_client.projects.get_outputs('1')

        assert outputs.total == 1
        assert len(outputs) == 1
        assert list(outputs)[0].source == output_server_data['source']

    def test_get_outputs_with_params(self, datarobotai_client, requests_mock, output_server_data):
        expected = {
            'total': 1,
            'data': [output_server_data],
            'links': {'next': None, 'previous': None}
        }
        requests_mock.register_uri('GET', 'http://example.com/projects/1/outputs/?offset=2&limit=4',
                                   headers={'content-type': 'application/json'}, json=expected)

        outputs = datarobotai_client.projects.get_outputs('1', offset=2, limit=4)

        assert outputs.total == 1
        assert len(outputs) == 1
        assert list(outputs)[0].source == output_server_data['source']

    @pytest.mark.parametrize('output_name, encoded_name', [('abc', 'abc'), ('Pinot Noir?', 'Pinot%20Noir%3F')])
    def test_get_output(self, datarobotai_client, requests_mock, output_server_data, output_name, encoded_name):
        output_server_data['name'] = output_name
        requests_mock.register_uri(
            'GET', 'http://example.com/projects/1/outputs/{}'.format(encoded_name),
            headers={'content-type': 'application/json'}, json=output_server_data
        )

        output = datarobotai_client.projects.get_output('1', output_server_data['name'])

        assert output.source == output_server_data['source']

    @pytest.mark.parametrize('output_name, encoded_name', [('abc', 'abc'), ('Pinot Noir?', 'Pinot%20Noir%3F')])
    def test_get_output_features(self, datarobotai_client, requests_mock, feature_data, output_name, encoded_name):

        requests_mock.register_uri(
            'GET', 'http://example.com/projects/1/outputs/{}/features/'.format(encoded_name),
            json=feature_data)

        features = datarobotai_client.projects.get_output_features('1', output_name)

        assert len(features.feature_list) == 2
        for i in range(0, len(feature_data['features'])):
            assert features.feature_list[i].feature_type == feature_data['features'][i]['type']
            assert features.feature_list[i].name == feature_data['features'][i]['name']

    @pytest.mark.parametrize('output_name, encoded_name', [('abc', 'abc'), ('Pinot Noir?', 'Pinot%20Noir%3F')])
    def test_get_output_features_output_object(self, datarobotai_client, requests_mock, output_server_data,
                                               feature_data, output_name, encoded_name):
        output_server_data['name'] = output_name
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/outputs/{}'.format(encoded_name),
            headers={'content-type': 'application/json'}, json=output_server_data
        )

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/outputs/%s/features/' % encoded_name,
            json=feature_data)

        output = datarobotai_client.projects.get_output('1', output_server_data['name'])

        features = output.get_features()
        for i in range(0, len(feature_data['features'])):
            assert features.feature_list[i].feature_type == feature_data['features'][i]['type']
            assert features.feature_list[i].name == feature_data['features'][i]['name']

    def test_output_features_can_find_feature(self, feature_data):
        output_features = OutputFeatures.from_server(feature_data)
        assert output_features.find_feature('col1').name == 'col1'

        assert not output_features.find_feature('asdfadsf')
