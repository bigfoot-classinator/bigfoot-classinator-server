"""Unit tests for Prediction model."""

import pytest

from datarobotai.models.prediction import Prediction


class TestPrediction(object):

    @pytest.fixture
    def sample_prediction_args(self, ):
        return {
            'row': 0,
            'prediction': 'Low',
            'values': [],  # dict doesn't support ordered representation
        }

    @pytest.fixture
    def sample_prediction_representation(self):
        return 'Prediction(0, \'Low\', [])'

    def test_prediction_representation(self, sample_prediction_args, sample_prediction_representation):
        pred = Prediction(**sample_prediction_args)
        assert str(pred) == sample_prediction_representation
