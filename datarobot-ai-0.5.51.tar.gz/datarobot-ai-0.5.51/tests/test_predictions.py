# - *- coding: utf- 8 - *-

import datetime

import six
import pandas as pd
import pytest
import numpy as np

from datarobotai.http_client import InputError, LimitExceededError
from datarobotai.models.deployment import Deployment


class TestPredictions(object):

    @pytest.fixture
    def sample_deployment_data(self):
        return {
            'url': 'http://predserver.net/',
            'datarobot-key': 'a-server-key',
            'deploymentId': '123',
        }

    @pytest.fixture
    def sample_invalid_deployment_data(self):
        circular_ref_sample = {}
        circular_ref = {'ref': circular_ref_sample}
        circular_ref_sample['ref'] = circular_ref
        return {
            'type': {'id': 1, 'price': 20, 'date': datetime.datetime.now()},
            'circular_ref': circular_ref_sample,
            'encoding': {'test_word': bytes(u'привет'.encode('utf-16'))}  # please, turn on utf-8 encoding explicitly
        }

    @pytest.fixture
    def sample_output_data(self, sample_deployment_data):
        return {'name': 'a name',
                'target': 'a target',
                'source': sample_deployment_data}

    @pytest.fixture
    def sample_deployment(self, sample_deployment_data):
        return Deployment.from_server(sample_deployment_data)

    @pytest.fixture
    def sample_predictions(self):
        return {
            'data': [{
                'rowId': 0,
                'prediction': 'alpha',
                'predictionValues': [{
                    'value': 0.49,
                    'label': 'beta'
                }, {
                    'value': 0.51,
                    'label': 'alpha'
                }]
            }, {
                'rowId': 1,
                'prediction': 'beta',
                'predictionValues': [{
                    'value': 0.49,
                    'label': 'alpha'
                }, {
                    'value': 0.51,
                    'label': 'beta'
                }]
            }]
        }

    @pytest.fixture
    def sample_numpy_payload(self):
        return {
            'source': {
                'val_1': np.int32(123),
                'val_2': None,
                'val_3': np.float(1.1),
                'array': np.array([1, 2, 3]),
            },
            'encoded': {
                'val_1': 123,
                'val_2': None,
                'val_3': 1.1,
                'array': [1, 2, 3],
            },
        }

    @pytest.fixture
    def sample_multiclass_predictions(self):
        return {
            'data': [{
                'rowId': 0,
                'prediction': 'alpha',
                'predictionValues': [{
                    'value': 0.25,
                    'label': 'beta'
                }, {
                    'value': 0.50,
                    'label': 'alpha'
                }, {
                    'value': 0.25,
                    'label': 'gamma'
                }]
            }, {
                'rowId': 1,
                'prediction': 'beta',
                'predictionValues': [{
                    'value': 0.50,
                    'label': 'beta'
                }, {
                    'value': 0.25,
                    'label': 'alpha'
                }, {
                    'value': 0.25,
                    'label': 'gamma'
                }]
            }, {
                'rowId': 2,
                'prediction': 'gamma',
                'predictionValues': [{
                    'value': 0.25,
                    'label': 'beta'
                }, {
                    'value': 0.25,
                    'label': 'alpha'
                }, {
                    'value': 0.50,
                    'label': 'gamma'
                }]
            }]
        }

    @pytest.fixture
    def sample_limit_exceeded_error_body(self):
        return {'message': 'Prediction Rows limit exceeded.'}

    @pytest.mark.parametrize('auth_type', ['Bearer'])
    def test_prediction_uses_client_headers(self, requests_mock,
                                            datarobotai_client,
                                            sample_predictions,
                                            sample_deployment,
                                            auth_type):
        datarobotai_client.session.set_auth(auth_type)
        assert auth_type in datarobotai_client.session.headers['Authorization']

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            request_headers=datarobotai_client.session.headers,
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions)

        datarobotai_client.predictions.deployment_predict(sample_deployment, 'tests/some-file.csv')

    def test_prediction_predict_returns_task(self, requests_mock,
                                             datarobotai_client,
                                             sample_predictions,
                                             sample_deployment):
        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions)

        result = datarobotai_client.predictions.deployment_predict(sample_deployment,
                                                                   'tests/some-file.csv')

        assert result.total == 2
        predictions = list(result)
        assert predictions[0].row == 0
        assert predictions[0].prediction == 'alpha'
        assert predictions[0].values == [{'label': 'beta', 'value': 0.49},
                                         {'label': 'alpha', 'value': 0.51}]
        assert predictions[1].row == 1
        assert predictions[1].prediction == 'beta'
        assert predictions[1].values == [{'label': 'alpha', 'value': 0.49},
                                         {'label': 'beta', 'value': 0.51}]

    def test_prediction_proba_helper(self, requests_mock, datarobotai_client, sample_predictions,
                                     sample_deployment):
        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions)

        preds = datarobotai_client.predictions.deployment_predict(sample_deployment,
                                                                  'tests/some-file.csv')
        preds_proba = [p.score_for('alpha') for p in preds]
        assert list(preds_proba) == [0.51, 0.49]

    def test_prediction_proba_helper_multiclass(self, requests_mock, datarobotai_client,
                                                sample_multiclass_predictions,
                                                sample_deployment):
        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_multiclass_predictions)

        preds = datarobotai_client.predictions.deployment_predict(sample_deployment,
                                                                  'tests/some-file.csv')
        preds_proba = [p.score_for('gamma') for p in preds]
        assert list(preds_proba) == [0.25, 0.25, 0.50]

    def test_prediction_proba_helper_fail(self, requests_mock, datarobotai_client,
                                          sample_multiclass_predictions,
                                          sample_deployment):
        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_multiclass_predictions)

        preds = datarobotai_client.predictions.deployment_predict(sample_deployment,
                                                                  'tests/some-file.csv')
        with pytest.raises(ValueError):
            list(preds)[0].score_for('theta')

    @pytest.mark.parametrize('invalidity_type', ['type', 'circular_ref', 'encoding'])
    def test_prediction_proba_helper_invalid_input_value_error(self, datarobotai_client, sample_deployment,
                                                               sample_invalid_deployment_data, invalidity_type):
        with pytest.raises(ValueError) as exec_info:
            datarobotai_client.predictions.deployment_predict(
                sample_deployment, sample_invalid_deployment_data[invalidity_type])
        assert 'Invalid input object.' in str(exec_info)

    def test_predict_json_helper_with_numpy_types(self, requests_mock, sample_numpy_payload, datarobotai_client,
                                                  sample_deployment, sample_predictions):
        def match_bodies(request):
            sent_body = request.json()[0]
            expected_body = sample_numpy_payload['encoded']
            equal = [len(sent_body) == len(expected_body)]
            for key, value in sent_body.items():
                equal.append(expected_body[key] == value)
            return all(equal)
        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions,
            additional_matcher=match_bodies
        )
        datarobotai_client.predictions.deployment_predict(sample_deployment, sample_numpy_payload['source'])

    def test_project_predict(self, requests_mock,
                             datarobotai_client,
                             sample_predictions,
                             sample_output_data):
        project_id = '123'
        target = 'my target'

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions)

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/{}/outputs/my%20target'.format(project_id),
            headers={'content-type': 'application/json'},
            json=sample_output_data
        )

        result = datarobotai_client.predictions.project_predict(project_id,
                                                                target, 'tests/some-file.csv')

        assert result.total == 2
        predictions = list(result)
        assert predictions[0].row == 0
        assert predictions[0].prediction == 'alpha'
        assert predictions[0].values == [{'label': 'beta', 'value': 0.49},
                                         {'label': 'alpha', 'value': 0.51}]
        assert predictions[1].row == 1
        assert predictions[1].prediction == 'beta'
        assert predictions[1].values == [{'label': 'alpha', 'value': 0.49},
                                         {'label': 'beta', 'value': 0.51}]

    def test_project_predict_with_data_frame(self, requests_mock,
                                             datarobotai_client,
                                             sample_predictions,
                                             sample_output_data):
        def match_file(request):
            sent_csv_df = pd.read_csv(six.StringIO(request.text)).fillna('')
            expected_df = pd.read_csv('tests/some-file.csv')
            return sent_csv_df.to_string() == expected_df.to_string()
        project_id = '123'
        target = 'my target'

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            additional_matcher=match_file,
            json=sample_predictions)

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/{}/outputs/my%20target'.format(project_id),
            headers={'content-type': 'application/json'},
            json=sample_output_data
        )
        input_data_frame = pd.read_csv('tests/some-file.csv')
        result = datarobotai_client.predictions.project_predict(project_id,
                                                                target, input_data_frame)

        assert result.total == 2
        predictions = list(result)
        assert predictions[0].row == 0
        assert predictions[0].prediction == 'alpha'
        assert predictions[0].values == [{'label': 'beta', 'value': 0.49},
                                         {'label': 'alpha', 'value': 0.51}]
        assert predictions[1].row == 1
        assert predictions[1].prediction == 'beta'
        assert predictions[1].values == [{'label': 'alpha', 'value': 0.49},
                                         {'label': 'beta', 'value': 0.51}]

    def test_project_predict_without_learn_errors(self, requests_mock,
                                                  datarobotai_client,
                                                  sample_predictions):
        project_id = '123'
        target = 'my target'

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions)

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/{}/outputs/my%20target'.format(project_id),
            headers={'content-type': 'application/json'},
            status_code=404
        )

        with pytest.raises(InputError):
            predict = datarobotai_client.predictions.project_predict(project_id,
                                                                     target, 'tests/some-file.csv')
            predict(project_id, target, 'tests/some-file.csv')

    def test_project_predict_with_limit_exceeded_errors(self, requests_mock, datarobotai_client,
                                                        sample_output_data, sample_limit_exceeded_error_body):
        project_id, target = '123', 'my target'

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/{}/outputs/my%20target'.format(project_id),
            headers={'content-type': 'application/json'},
            json=sample_output_data
        )

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=429,
            headers={'content-type': 'application/json'},
            json=sample_limit_exceeded_error_body
        )

        with pytest.raises(LimitExceededError) as limit_exceeded_error:
            predict = datarobotai_client.predictions.project_predict(project_id, target, 'tests/some-file.csv')
            predict(project_id, target, 'tests/some-file.csv')
        assert sample_limit_exceeded_error_body['message'] in str(limit_exceeded_error)

    def test_client_predict_in_memory(self, requests_mock, datarobotai_client,
                                      sample_predictions, sample_output_data,
                                      request_grabber):
        project_id = '123'
        target = 'my target'

        requests_mock.register_uri(
            'POST',
            'http://predserver.net/',
            status_code=200,
            headers={'content-type': 'application/json'},
            json=sample_predictions,
            additional_matcher=request_grabber
        )

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/{}/outputs/my%20target'.format(project_id),
            headers={'content-type': 'application/json'},
            json=sample_output_data
        )

        datarobotai_client.predictions.project_predict(project_id,
                                                       target,
                                                       data={'foo': 1})

        assert request_grabber.requests[0].headers['Content-Type'] == 'application/json'
