import mock
import pytest

from datarobotai.http_client import ServerError, ClientError, InputError
from datarobotai.models.dataset import Dataset
from datarobotai.models.learning_session import LearningSession
from datarobotai.models.project import Project
from datarobotai.projects import ProjectClient


@pytest.fixture()
def create_func():
    def create(client, name):
        return client.projects.create_project(project_name=name)
    return create


@pytest.fixture()
def fetch_func():
    def fetch(client, project_id):
        return client.projects.get(project_id)
    return fetch


@pytest.fixture()
def add_session_func():
    def fetch(client, project_id, session_id, output_name="default_output_name"):
        return client.projects.add_learning_session(project_id=project_id,
                                                    learning_session_id=session_id,
                                                    output_name=output_name)
    return fetch


class TestProjects(object):

    @pytest.fixture
    def empty_project(self):
        return {
            'id': '1',
            'name': 'Cool Workspace',
            'learningSessionCount': 0,
            'outputCount': 0,
            'datasetCount': 0
        }

    @pytest.fixture
    def filled_project(self):
        return {
            'id': '1',
            'name': 'Cool Workspace',
            'outputCount': 1,
            'learningSessionCount': 1,
            'datasetCount': 1
        }

    @pytest.fixture
    def dataset(self):
        return Dataset(
            dataset_id='1',
            name='foo',
            created_on='',
            client=mock.Mock()
        )

    @pytest.fixture
    def sample_response_crete_output(self):
        return {
            'links':
                {
                    'result': 'http://example.com/aiapi/projects/1/outputs/output/'
                }
        }

    @pytest.fixture
    def filled_project_response(self, requests_mock, datarobotai_client, filled_project,
                                sample_learning_session_list, sample_dataset_list):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/',
            request_headers=datarobotai_client.session.headers,
            headers={'content-type': 'application/json'},
            json=filled_project
        )
        requests_mock.register_uri(
            'GET',
            'http://example.com/learningSessions/?projectId=1',
            headers={'content-type': 'application/json'},
            json=sample_learning_session_list
        )
        requests_mock.register_uri(
            'GET', 'http://example.com/datasets/?projectId=1&offset=0&limit=50',
            headers={'content-type': 'application/json'},
            json=sample_dataset_list

        )

    @pytest.mark.parametrize('auth_type', ['Bearer'])
    def test_uses_client_headers(self, datarobotai_client, requests_mock,
                                 empty_project, auth_type, fetch_func):
        datarobotai_client.session.set_auth(auth_type)
        assert auth_type in datarobotai_client.session.headers['Authorization']

        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/',
            request_headers=datarobotai_client.session.headers,
            headers={'content-type': 'application/json'},
            json=empty_project
        )

        fetch_func(datarobotai_client, '1')

    def test_create(self, datarobotai_client, requests_mock, empty_project, create_func):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/',
            json={'links': {'result': 'http://example.com/projects/1'}},
            status_code=201
        )
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1',
            headers={'content-type': 'application/json'},
            json=empty_project
        )

        project = create_func(datarobotai_client, 'Cool Workspace')
        assert project.name == 'Cool Workspace'
        assert project.project_id == '1'
        assert project.project_id == project.id

    def test_create_fail(self, datarobotai_client, create_func, requests_mock):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/',
            status_code=500
        )
        with pytest.raises(ServerError):
            create_func(datarobotai_client, 'Cool Workspace')

    def test_fetch(self, datarobotai_client, requests_mock, empty_project, fetch_func):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/',
            headers={'content-type': 'application/json'},
            json=empty_project
        )

        project = fetch_func(datarobotai_client, '1')
        assert project.name == 'Cool Workspace'
        assert project.project_id == '1'

    def test_project_list(self, requests_mock, datarobotai_client):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/',
            headers={'content-type': 'application/json'},
            json={
                'data': [{
                    'id': 'echo-foxtrot',
                    'name': 'ef.csv',
                    'outputCount': 0,
                    'learningSessionCount': 0,
                    'datasetCount': 0
                }],
                'total': 1
            })

        projects = ProjectClient(datarobotai_client)

        result = projects.list()

        assert result.total == 1
        assert len(result) == 1

    def test_project_list_with_params(self, requests_mock, datarobotai_client):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/?offset=1&limit=10',
            headers={'content-type': 'application/json'},
            json={
                'data': [{
                    'id': 'echo-foxtrot',
                    'name': 'ef.csv',
                    'learningSessionCount': 0,
                    'outputCount': 0,
                    'datasetCount': 0
                }],
                'total': 1
            })

        projects = ProjectClient(datarobotai_client)

        result = projects.list(offset=1, limit=10)

        assert result.total == 1
        assert len(result) == 1

    @pytest.mark.usefixtures('filled_project_response')
    def test_fetch_filled(self, datarobotai_client, fetch_func,
                          sample_learning_session_list, sample_dataset_list):

        project = fetch_func(datarobotai_client, '1')
        assert project.name == 'Cool Workspace'
        assert project.project_id == '1'

        sessions = project.get_learning_sessions()
        sessions_list = list(sessions)
        assert sessions_list[0].name == sample_learning_session_list['data'][0]['name']
        assert sessions_list[0].id == sample_learning_session_list['data'][0]['id']
        assert sessions.total == len(sample_learning_session_list['data'])

        datasets = project.get_datasets()
        datasets_list = list(datasets)
        assert datasets_list[0].name == sample_dataset_list['data'][0]['datasetName']
        assert datasets_list[0].id == sample_dataset_list['data'][0]['id']
        assert datasets.total == len(sample_dataset_list['data'])

    @pytest.mark.usefixtures('filled_project_response')
    def test_paginator_repr(self, datarobotai_client, fetch_func):
        project = fetch_func(datarobotai_client, '1')
        sessions = project.get_learning_sessions()

        assert repr(sessions) == 'Paginator(factory=LearningSessionFactory, total=2)'

    def test_project_eq(self, datarobotai_client, requests_mock, filled_project):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/',
            headers={'content-type': 'application/json'},
            json=filled_project
        )

        project_one = datarobotai_client.projects.get('1')
        project_two = datarobotai_client.projects.get('1')
        assert project_one == project_two

    def test_fetch_fail(self, datarobotai_client, requests_mock, fetch_func):
        requests_mock.register_uri(
            'GET',
            'http://example.com/projects/1/',
            status_code=500
        )
        with pytest.raises(ServerError):
            fetch_func(datarobotai_client, '1')

    def test_add_learning_session(self, datarobotai_client, requests_mock,
                                  add_session_func):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/learningSessions/',
            headers={'content-type': 'application/json'},
            status_code=201,
            json=''
        )

        some_session = LearningSession(
            _id='1',
            dataset_id='1',
            name='Dollars',
            target='cents',
            created='right now',
            client=mock.Mock()
        )

        add_session_func(datarobotai_client, '1', some_session.learning_session_id)

    @pytest.mark.usefixtures('filled_project_response')
    def test_add_learning_session_from_object(self, datarobotai_client, requests_mock):

        def match_body(request):
            body = request.json()
            return 'learningSessionId' in body and 'outputName' not in body

        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/learningSessions/',
            headers={'content-type': 'application/json'},
            status_code=201,
            json='',
            additional_matcher=match_body
        )

        some_session = LearningSession(
            _id='1',
            dataset_id='1',
            name='Dollars',
            target='cents',
            created='right now',
            client=mock.Mock()
        )

        project = Project('1', 'foo', 0, 0, 0, datarobotai_client)

        project.add_learning_session(learning_session=some_session)

    @pytest.mark.usefixtures('filled_project_response')
    def test_add_learning_session_from_object_with_output(self, datarobotai_client, requests_mock):
        def match_body(request):
            body = request.json()
            return 'learningSessionId' in body and 'outputName' in body

        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/learningSessions/',
            headers={'content-type': 'application/json'},
            status_code=201,
            json='',
            additional_matcher=match_body
        )

        some_session = LearningSession(
            _id='1',
            dataset_id='1',
            name='Dollars',
            target='cents',
            created='right now',
            client=mock.Mock()
        )

        project = Project('1', 'foo', 0, 0, 0, datarobotai_client)

        project.add_learning_session(learning_session=some_session, output_name='Foo')

    def test_add_learning_session_fail(self, datarobotai_client, add_session_func,
                                       requests_mock):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/learningSessions/',
            status_code=500,
        )
        some_session = LearningSession(
            _id='1',
            dataset_id='1',
            name='Dollars',
            target='cents',
            created='right now',
            client=mock.Mock()
        )
        with pytest.raises(ServerError):
            add_session_func(datarobotai_client, '1', some_session.learning_session_id)

    def test_add_dataset(self, datarobotai_client, dataset, requests_mock):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/datasets/',
            headers={'content-type': 'application/json'},
            status_code=201,
            json=''
        )

        datarobotai_client.projects.add_dataset(project_id='1',
                                                dataset_id=dataset.dataset_id)

    @pytest.mark.usefixtures('filled_project_response')
    def test_add_dataset_from_object(self, datarobotai_client, dataset, requests_mock):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/datasets/',
            headers={'content-type': 'application/json'},
            status_code=201,
            json=''
        )

        project = Project('1', 'foo', 0, 0, 0, datarobotai_client)
        project.add_dataset(dataset=dataset)

    def test_add_dataset_fail(self, datarobotai_client, dataset, requests_mock):
        requests_mock.register_uri(
            'POST',
            'http://example.com/projects/1/datasets/',
            headers={'content-type': 'application/json'},
            status_code=500,
            json=''
        )

        with pytest.raises(ServerError):
            datarobotai_client.projects.add_dataset(project_id='1',
                                                    dataset_id=dataset.dataset_id)

    @pytest.mark.parametrize('data_source,expected_match', [
        (None, 'Input error: Unexpected type of the input value. NoneType has been passed,'
               ' but list, filepath or dataset id are expected.'),
        ({'foo': 'bar'}, 'Input error: Unexpected type of the input value. dict has been passed,'
                         ' but list, filepath or dataset id are expected.'),
    ])
    def test_project_validates_learn_input(self, datarobotai_client,
                                           data_source, expected_match):
        project = Project('1', 'foo', 0, 0, 0, datarobotai_client)
        with pytest.raises(InputError, match=expected_match):
            project.learn('foo', data_source)

    @pytest.fixture
    def mock_learning_client(self):
        with mock.patch('datarobotai.client.DataRobotAIClient.learning') as l:
            yield l

    @pytest.fixture
    def mock_import_file(self):
        with mock.patch('datarobotai.data.Data.import_file') as d:
            yield d

    @pytest.fixture
    def mock_import_buffer(self):
        with mock.patch('datarobotai.data.Data._import_buffer') as d:
            yield d

    @pytest.fixture
    def mock_add_learning_session(self):
        with mock.patch('datarobotai.models.project.Project.add_learning_session') as l:
            yield l

    @pytest.fixture
    def mock_add_dataset(self):
        with mock.patch('datarobotai.models.project.Project._add_dataset_by_id') as l:
            yield l

    @pytest.mark.parametrize('data_source', [
        '5c9a5ca734e5401b901173c6', 'tests/some-file.csv', [{'foo': 'bar'}]])
    def test_project_learn_adds_dataset_and_learning_session(self,
                                                             datarobotai_client,
                                                             data_source,
                                                             mock_learning_client,
                                                             mock_import_file,
                                                             mock_import_buffer,
                                                             mock_add_learning_session,
                                                             mock_add_dataset):

        project_id = "1"
        project = Project(project_id, 'foo', 0, 0, 0, datarobotai_client)

        mock_import_file.return_value = Dataset("2",
                                                "foo",
                                                None,
                                                datarobotai_client)

        mock_import_buffer.return_value = Dataset('2',
                                                  'foo',
                                                  None,
                                                  datarobotai_client)

        mock_learning_client.learn.return_value = LearningSession(
            "3", "2", "Learn", "target", None, datarobotai_client
        )

        project.learn('foo', data_source)

        assert mock_add_learning_session.called
        assert mock_add_dataset.called

    def test_delete_project(self, datarobotai_client, requests_mock):

        requests_mock.register_uri(
            'DELETE',
            'http://example.com/projects/1/',
            headers={'content-type': 'application/json'},
            status_code=204,
            json=''
        )

        datarobotai_client.projects.delete('1')

    def test_delete_project_missing(self, datarobotai_client, requests_mock):
        requests_mock.register_uri(
            'DELETE',
            'http://example.com/projects/1/',
            headers={'content-type': 'application/json'},
            status_code=404,
            json=''
        )

        with pytest.raises(ClientError):
            datarobotai_client.projects.delete('1')

    @pytest.mark.parametrize('output_name', [None, 'credit_risk'])
    def test_add_output(self, datarobotai_client, requests_mock, sample_response_crete_output, output_name):
        learning_session_id = 42
        project_id = 1

        def match_body(request):
            body = request.json()
            learning_session_val = 'learningSessionId' in body and body['learningSessionId'] == 42
            output_name_val = True if not output_name else 'outputName' in body and body['outputName'] == output_name
            return learning_session_val and output_name_val

        requests_mock.register_uri(
            'PUT',
            'http://example.com/projects/{}/outputs/'.format(project_id),
            headers={'content-type': 'application/json'},
            status_code=201,
            json=sample_response_crete_output,
            additional_matcher=match_body
        )

        datarobotai_client.projects.add_output(
            project_id=project_id, learning_session_id=learning_session_id, output_name=output_name)

    def test_add_output_fail(self, datarobotai_client, requests_mock):
        requests_mock.register_uri(
            'PUT',
            'http://example.com/projects/1/outputs/',
            headers={'content-type': 'application/json'},
            status_code=500,
            json='',
        )

        with pytest.raises(ServerError):
            datarobotai_client.projects.add_output(project_id='1', learning_session_id='tango')

    @pytest.mark.usefixtures('filled_project_response')
    def test_add_output_from_object(self, datarobotai_client, requests_mock, sample_response_crete_output):
        project_id, learning_session_id = '1', 'tango'

        def match_body(request):
            body = request.json()
            return 'learningSessionId' in body and body['learningSessionId'] == learning_session_id

        requests_mock.register_uri(
            'PUT',
            'http://example.com/projects/{}/outputs/'.format(project_id),
            headers={'content-type': 'application/json'},
            status_code=201,
            json=sample_response_crete_output,
            additional_matcher=match_body
        )

        project = Project(project_id, 'foo', 0, 1, 0, datarobotai_client)
        project.add_output(learning_session_id=learning_session_id)
