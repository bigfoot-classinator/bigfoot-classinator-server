import pytest

from datarobotai.statuses import Statuses


@pytest.mark.parametrize('auth_type', ['Bearer'])
def test_status_uses_client_headers(requests_mock, datarobotai_client, auth_type):
    datarobotai_client.session.set_auth(auth_type)
    assert auth_type in datarobotai_client.session.headers['Authorization']

    requests_mock.register_uri(
        'GET',
        'http://example.com/status/',
        request_headers=datarobotai_client.session.headers,
        headers={'content-type': 'application/json'},
        json={
            'data': [],
            'total': 1
        })

    ds = Statuses(datarobotai_client)

    ds.list()


def test_status_list(requests_mock, datarobotai_client):

    expected = {
        "status": "INITIALIZED",
        "code": 0,
        "description": "Full Training",
        "created": "2018-11-06T17:06:06.305260Z",
        "message": "",
        "statusType": "Session",
        "statusId": "7d495cee-78b4-43a2-a6ae-9091b2c8c55c"
    }

    requests_mock.register_uri(
        'GET',
        'http://example.com/status/',
        headers={'content-type': 'application/json'},
        json={
            'data': [expected],
            'total': 1
        })

    ds = Statuses(datarobotai_client)

    result = ds.list()

    assert result.total == 1
    assert len(result) == 1

    status = list(result)[0]
    assert status.status_id == expected['statusId']
    assert status.id == status.status_id
    assert status.status == expected['status']
    assert status.code == expected['code']
    assert status.description == expected['description']
    assert status.created == expected['created']
    assert status.message == expected['message']
    assert status.status_type == expected['statusType']
