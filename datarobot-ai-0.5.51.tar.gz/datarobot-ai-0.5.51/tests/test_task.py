from __future__ import print_function

import logging
import logging.handlers

import pytest
import requests
from mock import patch


from datarobotai.task import Task, TaskError, TaskTimeout
from datarobotai.http_client import RESTClientObject


@pytest.fixture
def no_sleep():
    with patch('datarobotai.task.sleep') as mock_sleep:
        yield mock_sleep


def handle_response(location):
    return requests.get(location).json()


def test_task_create():
    task = Task(None, 'foo', print)
    assert task is not None


def setup_basic_success(requests_mock):
    requests_mock.get('http://example.com/test',
                      [{'status_code': 200,
                        'json': {'status': 'completed', 'message': 'foo',
                                 'links': {'result': 'http://example.com/somewhere/else'}}}])
    requests_mock.get('http://example.com/somewhere/else', json={'charlie': 'delta'})


@pytest.fixture
def http_session():
    return RESTClientObject(token='a-key',
                            endpoint='http://example.com')


@pytest.mark.usefixtures('no_sleep')
def test_task_checks_for_completeness_when_asked_for_result(requests_mock, http_session):
    setup_basic_success(requests_mock)

    task = Task(http_session, 'http://example.com/test', handle_response)
    result = task.get_result(0)

    assert result == {'charlie': 'delta'}


@pytest.mark.usefixtures('no_sleep')
def test_task_returns_results_when_complete(requests_mock, http_session):
    setup_basic_success(requests_mock)

    task = Task(http_session, 'http://example.com/test', handle_response)

    result = task.get_result(0)

    assert result == {'charlie': 'delta'}


@pytest.mark.usefixtures('no_sleep')
def test_task_is_complete_when_actually_complete(requests_mock, http_session):
    setup_basic_success(requests_mock)

    task = Task(http_session, 'http://example.com/test', handle_response)

    assert task.is_complete()


@pytest.mark.usefixtures('no_sleep')
def test_task_is_success_on_success(requests_mock, http_session):
    requests_mock.get('http://example.com/test',
                      [{'status_code': 200,
                        'json': {'status': 'RUNNING',
                                 'message': 'Reticulating splines',
                                 'links': {
                                     'self': 'http://example.com/test'
                                 }},
                        'headers': {'content-type': 'application/json'}},
                       {'status_code': 200,
                        'json': {'status': 'completed', 'message': 'foo',
                                 'links': {'result': 'http://example.com/somewhere/else'}}}])
    requests_mock.get('http://example.com/somewhere/else', json={'charlie': 'delta'})

    task = Task(http_session, 'http://example.com/test', handle_response)
    task.get_result(1)

    assert task.is_successful()


@pytest.mark.usefixtures('no_sleep')
def test_task_is_successful_will_check_server(requests_mock, http_session):
    requests_mock.get('http://example.com/status/abc-status-id',
                      [{'status_code': 200,
                        'json': {'status': 'RUNNING',
                                 'message': 'Reticulating splines',
                                 'links': {
                                     'self': 'http://example.com/test'
                                 }},
                        'headers': {'content-type': 'application/json'}},
                       {'status_code': 200,
                        'json': {'status': 'COMPLETED',
                                 'message': 'foo',
                                 'links': {
                                     'result': 'http://example.com/somewhere/else'
                                 }}}])
    requests_mock.get('http://example.com/somewhere/else', json={'charlie': 'delta'})
    task = Task(http_session,
                'http://example.com/status/abc-status-id',
                get_callback=handle_response)
    assert not task.is_successful()  # first check should fail
    assert task.is_successful()  # second check has completion


@pytest.mark.usefixtures('no_sleep')
def test_task_sets_success_on_failure(requests_mock, http_session):
    requests_mock.get(
        'http://example.com/test',
        [{'status_code': 200,
          'json': {'status': 'RUNNING',
                   'message': 'Reticulating splines',
                   'links': {
                       'self': 'http://example.com/test'
                   }},
          'headers': {'content-type': 'application/json'}},
         {'status_code': 200,
          'json': {'status': 'RUNNING',
                   'message': 'Reticulating splines',
                   'links': {
                       'self': 'http://example.com/test'
                   }},
          'headers': {'content-type': 'application/json'}},
         {'status_code': 200,
          'json': {'status': 'ERROR',
                   'message': 'Oh the humanity!',
                   'links': {
                       'self': 'http://example.com/test'
                   }},
          'headers': {'content-type': 'application/json'}}])

    task = Task(http_session, 'http://example.com/test', handle_response)
    with pytest.raises(TaskError):
        task.get_result(100)

    assert task.is_complete()
    assert task.status == 'ERROR'
    assert task.message == 'Oh the humanity!'


@pytest.mark.usefixtures('no_sleep')
def test_task_sets_timed_out_when_waits_too_long(requests_mock, http_session):
    # will always return this response no matter how many times we ask
    requests_mock.get('http://example.com/test',
                      [{'status_code': 200,
                        'json': {'status': 'RUNNING',
                                 'message': 'Reticulating splines',
                                 'links': {
                                     'self': 'http://example.com/test'
                                 }},
                        'headers': {'content-type': 'application/json'}}])

    task = Task(http_session, 'http://example.com/test', handle_response)
    with pytest.raises(TaskTimeout):
        task.get_result(1e-9)

    assert task.timed_out


class LogSink:
    """A sink to attach to a MemoryHandler to get out all of the logs it sees"""
    def __init__(self):
        self.reservoir = []

    def handle(self, record):
        self.reservoir.append(record)


@pytest.fixture
def log_sink():
    return LogSink()


@pytest.fixture
def inmemory_logging_handler(log_sink):
    return logging.handlers.MemoryHandler(capacity=0, target=log_sink)


@pytest.yield_fixture
def task_logger(inmemory_logging_handler):
    logger = logging.getLogger('datarobotai.task')
    logger.addHandler(inmemory_logging_handler)
    logger.setLevel(logging.DEBUG)
    yield logger
    logger.removeHandler(inmemory_logging_handler)


@pytest.mark.usefixtures('no_sleep', 'task_logger')
def test_task_will_log_status_if_not_finished(requests_mock, log_sink, http_session):
    requests_mock.get('http://example.com/test',
                      [{'status_code': 200,
                        'json': {'status': 'RUNNING',
                                 'message': 'Reticulating splines',
                                 'links': {
                                     'self': 'http://example.com/test'
                                 }},
                        'headers': {'content-type': 'application/json'}}])

    task = Task(http_session, 'http://example.com/test', handle_response)
    with pytest.raises(TaskTimeout):
        task.get_result(timeout=100)

    assert task.timed_out
    assert log_sink.reservoir
    record = next(r for r in log_sink.reservoir if r.levelname == 'INFO')
    assert record.name == 'datarobotai.task'
    assert record.msg == 'RUNNING: Reticulating splines'
